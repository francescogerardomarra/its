package com.example.controller;

import com.example.dto.orderitem.OrderItemDTO;
import com.example.rest.request.orderitem.AddItemToOrderRequest;
import com.example.rest.request.orderitem.RemoveItemFromOrderRequest;
import com.example.rest.response.orderitem.AddItemToOrderResponse;
import com.example.rest.response.orderitem.RemoveItemFromOrderResponse;
import com.example.service.OrderItemService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/shop/orderitems")
public class OrderItemController {

    private static final Logger logger = LoggerFactory.getLogger(OrderItemController.class);

    private final OrderItemService orderItemService;

    @Autowired
    public OrderItemController(OrderItemService orderItemService) {
        this.orderItemService = orderItemService;
    }

    // Add an item to an order
    @PostMapping
    public ResponseEntity<AddItemToOrderResponse> addItemToOrder(@RequestBody AddItemToOrderRequest request) {
        logger.info("Received request to add item (itemId: {}) to order (orderId: {}) with quantity: {}",
                request.getItemId(), request.getOrderId(), request.getQuantity());

        // Convert the request into a DTO
        OrderItemDTO orderItemDTO = new OrderItemDTO(
                request.getOrderId(),
                request.getItemId(),
                request.getQuantity()
        );

        // Call the service layer
        Optional<OrderItemDTO> responseDTO = orderItemService.addItemToOrder(orderItemDTO);

        // Check if the order item was successfully added or not
        if (responseDTO.isEmpty()) {
            logger.warn("Failed to add item (itemId: {}) to order (orderId: {}).", request.getItemId(), request.getOrderId());
            return ResponseEntity.badRequest().body(new AddItemToOrderResponse(
                    request.getOrderId(), request.getItemId(), request.getQuantity(), "Item not added to order."));
        }

        // Build a success response
        AddItemToOrderResponse response = new AddItemToOrderResponse(
                responseDTO.get().getOrderId(),
                responseDTO.get().getItemId(),
                responseDTO.get().getQuantity(),
                "Item successfully added to the order."
        );

        logger.info("Successfully added item (itemId: {}) to order (orderId: {}).", responseDTO.get().getItemId(), responseDTO.get().getOrderId());
        return ResponseEntity.ok(response);
    }

    // Remove an item from an order
    @DeleteMapping
    public ResponseEntity<RemoveItemFromOrderResponse> removeItemFromOrder(@RequestBody RemoveItemFromOrderRequest request) {
        logger.info("Received request to remove item (itemId: {}) from order (orderId: {}).", request.getItemId(), request.getOrderId());

        // Convert the request into a DTO
        OrderItemDTO orderItemDTO = new OrderItemDTO(
                request.getOrderId(),
                request.getItemId(),
                null  // Quantity is not needed for removal
        );

        // Call the service layer
        Optional<OrderItemDTO> responseDTO = orderItemService.removeItemFromOrder(orderItemDTO);

        // Check if the order item was successfully removed or not
        if (responseDTO.isEmpty()) {
            logger.warn("Failed to remove item (itemId: {}) from order (orderId: {}).", request.getItemId(), request.getOrderId());
            return ResponseEntity.badRequest().body(new RemoveItemFromOrderResponse(
                    request.getOrderId(), request.getItemId(), "Item not found in the order."));
        }

        // Build a success response
        RemoveItemFromOrderResponse response = new RemoveItemFromOrderResponse(
                responseDTO.get().getOrderId(),
                responseDTO.get().getItemId(),
                "Item successfully removed from the order."
        );

        logger.info("Successfully removed item (itemId: {}) from order (orderId: {}).", responseDTO.get().getItemId(), responseDTO.get().getOrderId());
        return ResponseEntity.ok(response);
    }
}
