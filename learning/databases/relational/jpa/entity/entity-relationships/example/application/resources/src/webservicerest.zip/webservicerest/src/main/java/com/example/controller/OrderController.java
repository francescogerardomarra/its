package com.example.controller;

import com.example.model.Order;
import com.example.model.User;
import com.example.rest.request.order.OrderRequest;
import com.example.rest.request.order.RemoveOrderRequest;
import com.example.rest.response.order.RemoveOrderResponse;
import com.example.rest.response.order.OrderResponse;
import com.example.service.OrderService;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/shop/orders")  // Class-level mapping
public class OrderController {

    private final OrderService orderService;
    private final UserService userService;

    @Autowired
    public OrderController(OrderService orderService, UserService userService) {
        this.orderService = orderService;
        this.userService = userService;
    }

    // Create a new order (without items initially)
    @PostMapping  // Method-level mapping
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest orderRequest) {
        Optional<User> user = userService.getUserById(orderRequest.getUserId());
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Create and save the order
        Order order = new Order();
        order.setUser(user.get());

        Order savedOrder = orderService.saveOrder(order);

        // Directly creating the response here
        OrderResponse response = new OrderResponse(
                savedOrder.getOrderId(),
                savedOrder.getOrderDate(),
                savedOrder.getStatus(),
                savedOrder.getUser().getUserId(),
                savedOrder.getOrderItems()  // Initially empty, will be populated later
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve an order by its ID with explicit parameter
    @GetMapping(params = "orderId")  // Method-level mapping with explicit param
    public ResponseEntity<OrderResponse> getOrderById(@RequestParam Integer orderId) {
        Optional<Order> order = orderService.getOrderById(orderId);
        if (order.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Directly creating the response here
        OrderResponse response = new OrderResponse(
                order.get().getOrderId(),
                order.get().getOrderDate(),
                order.get().getStatus(),
                order.get().getUser().getUserId(),
                order.get().getOrderItems()  // This will contain the list of items for the order
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve orders by user ID
    @GetMapping(params = "userId")  // Method-level mapping with userId parameter
    public ResponseEntity<List<OrderResponse>> getOrdersByUserId(@RequestParam Integer userId) {
        List<Order> orders = orderService.getOrdersByUserId(userId);
        if (orders.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        List<OrderResponse> responses = orders.stream()
                .map(order -> new OrderResponse(
                        order.getOrderId(),
                        order.getOrderDate(),
                        order.getStatus(),
                        order.getUser().getUserId(),
                        order.getOrderItems()))  // Convert each Order to OrderResponse
                .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    // Delete an order by its ID
    @DeleteMapping  // Method-level mapping
    public ResponseEntity<RemoveOrderResponse> deleteOrder(@RequestBody RemoveOrderRequest request) {
        Optional<Order> order = orderService.getOrderById(request.getOrderId());
        if (order.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        orderService.deleteOrder(request.getOrderId());

        // Directly creating the response here
        RemoveOrderResponse response = new RemoveOrderResponse(
                request.getOrderId(),
                "Order deleted successfully"
        );

        return ResponseEntity.ok(response);
    }
}
