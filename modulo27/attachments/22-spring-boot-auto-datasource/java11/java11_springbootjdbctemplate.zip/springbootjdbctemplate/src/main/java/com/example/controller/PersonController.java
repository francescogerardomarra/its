package com.example.controller;

import com.example.model.Person;
import com.example.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/person")
public class PersonController {
    private final PersonService personService;

    @Autowired // Explicitly declare constructor injection
    public PersonController(PersonService personService) {
        this.personService = personService;
    }

    @PostMapping("/add")
    public String addPerson(@RequestParam String name,
                            @RequestParam String surname,
                            @RequestParam String city,
                            @RequestParam int age) {
        Person person = new Person(name, surname, city, age);
        personService.savePerson(person);
        return "Person added successfully";
    }
}
