package com.example.rest.response.user;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Response class for removing a User.
 * This response will confirm that a User has been successfully removed from the system.
 */
@Getter
@Setter
@AllArgsConstructor
public class RemoveUserResponse {

    @JsonProperty("user_id")
    private Integer userId;

    @JsonProperty("message")
    private String message;
}
