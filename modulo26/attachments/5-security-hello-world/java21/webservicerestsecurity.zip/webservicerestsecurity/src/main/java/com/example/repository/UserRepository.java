package com.example.repository;

import com.example.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * The `UserRepository` interface provides basic CRUD operations for the `User` entity.
 * By extending `JpaRepository`, it automatically inherits several methods for working with the `User` entity.
 * <p>
 * Basic CRUD methods provided by JpaRepository:
 * - `save(S entity)` - Persists a given `User` entity to the database (both insert and update).
 * - `findById(ID id)` - Retrieves a `User` entity by its primary key (`userId` in this case).
 * - `findAll()` - Returns a list of all `User` entities.
 * - `deleteById(ID id)` - Deletes a `User` entity by its primary key (`userId`).
 * - `delete(S entity)` - Deletes a specific `User` entity.
 * </p>
 * <p>
 * The methods `findByUsername` and `findByEmail` demonstrate how Spring Data JPA uses the method name conventions to automatically
 * generate queries. These conventions allow for creating custom queries without needing to explicitly define SQL or JPQL.
 * </p>
 * <h3>Method Name Conventions:</h3>
 * Spring Data JPA interprets method names based on certain conventions to automatically generate queries.
 * Some examples:
 * - `findBy` indicates a query to retrieve data.
 * - `By` separates the property name(s) that are part of the query.
 * - For example, `findByUsername(String username)` generates a query that searches for a `User` entity where the `username` field matches the provided value.
 * - The method names can also use logical operators like `And`, `Or`, `Between`, etc., to build more complex queries (e.g., `findByUsernameAndEmail`).
 * </p>
 */
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    /**
     * Retrieves a `User` by their unique `username`.
     * This method is automatically implemented by Spring Data JPA based on the method name convention.
     * Spring Data JPA generates a query like: `SELECT u FROM User u WHERE u.username = ?1`
     *
     * @param username The username of the user to find.
     * @return An `Optional` containing the `User` with the given `username`, or empty if no user is found.
     */
    Optional<User> findByUsername(String username);

    /**
     * Retrieves a `User` by their unique `email`.
     * This method is automatically implemented by Spring Data JPA based on the method name convention.
     * Spring Data JPA generates a query like: `SELECT u FROM User u WHERE u.email = ?1`
     *
     * @param email The email of the user to find.
     * @return An `Optional` containing the `User` with the given `email`, or empty if no user is found.
     */
    Optional<User> findByEmail(String email);
}
