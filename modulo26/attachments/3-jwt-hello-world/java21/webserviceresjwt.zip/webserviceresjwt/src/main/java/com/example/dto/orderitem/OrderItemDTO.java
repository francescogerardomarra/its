package com.example.dto.orderitem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class OrderItemDTO {

    private Integer orderId;
    private Integer itemId;
    private Integer quantity;
}