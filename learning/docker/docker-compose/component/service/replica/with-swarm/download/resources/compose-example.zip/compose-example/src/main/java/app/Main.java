package app;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        int i = 1;

        while (true){
            System.out.println("Hello World " + i++);
            Thread.sleep(10000);
        }
    }
}
