package com.example.actuatordemo;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class CustomHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        // Custom health check logic
        boolean isHealthy = true;  // Here you could check some service or condition
        if (isHealthy) {
            return Health.up().withDetail("customService", "Available").build();
        } else {
            return Health.down().withDetail("customService", "Unavailable").build();
        }
    }
}