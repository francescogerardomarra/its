package com.example;

public class Main {
    public static void main(String[] args) {
        try {
            // Paths to JSON files
            String validJson = "src/main/resources/person.json";
            String invalidJson = "src/main/resources/invalid_person.json";
            String malformedJson = "src/main/resources/malformed_person.json";
            
            // Deserialize valid JSON
            try {
                Person person = JsonHandler.deserializeFromJson(validJson);
                System.out.println("SUCCESS - Deserialized Person: " + person.getName() + ", Age: " + person.getAge());
            } catch (Exception e) {
                System.out.println("FAILURE - Error deserializing valid JSON: " + e.getMessage());
            }
            
            // Attempt to deserialize invalid JSON (wrong data type)
            try {
                Person invalidPerson = JsonHandler.deserializeFromJson(invalidJson);
                System.out.println("SUCCESS - Deserialized Invalid Person: " + invalidPerson.getName() + ", Age: " + invalidPerson.getAge());
            } catch (Exception e) {
                System.out.println("FAILURE - Failed to deserialize invalid JSON: " + e.getMessage());
            }
            
            // Attempt to deserialize malformed JSON (syntax error)
            try {
                Person malformedPerson = JsonHandler.deserializeFromJson(malformedJson);
                System.out.println("SUCCESS - Deserialized Malformed Person: " + malformedPerson.getName() + ", Age: " + malformedPerson.getAge());
            } catch (Exception e) {
                System.out.println("FAILURE - Failed to deserialize malformed JSON: " + e.getMessage());
            }
            
        } catch (Exception e) {
            System.out.println("FAILURE - Error during deserialization: " + e.getMessage());
        }
    }
}
