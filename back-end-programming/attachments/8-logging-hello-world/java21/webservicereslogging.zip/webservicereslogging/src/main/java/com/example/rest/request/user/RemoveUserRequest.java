package com.example.rest.request.user;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * Request class for removing a User.
 * Used when sending a DELETE request to remove a User by their ID.
 */
@Getter
@Setter
public class RemoveUserRequest {

    @NotNull(message = "User ID cannot be null")
    @JsonProperty("user_id")
    private Integer userId;
}
