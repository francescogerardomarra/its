package com.example.dto.order;

import com.example.dto.orderitem.OrderItemDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class OrderDTO {

    private Integer orderId;
    private LocalDateTime orderDate;
    private String status;
    private Integer userId;
    private List<OrderItemDTO> orderItems;
}