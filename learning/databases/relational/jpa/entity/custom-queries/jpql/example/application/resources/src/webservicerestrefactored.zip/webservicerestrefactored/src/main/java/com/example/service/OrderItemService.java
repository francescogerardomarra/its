package com.example.service;

import com.example.dto.orderitem.OrderItemDTO;
import com.example.model.Item;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.model.key.OrderItemKey;
import com.example.repository.ItemRepository;
import com.example.repository.OrderItemRepository;
import com.example.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OrderItemService {

    private final OrderItemRepository orderItemRepository;
    private final OrderRepository orderRepository;  // Inject the OrderRepository
    private final ItemRepository itemRepository;    // Inject the ItemRepository

    @Autowired
    public OrderItemService(OrderItemRepository orderItemRepository, OrderRepository orderRepository, ItemRepository itemRepository) {
        this.orderItemRepository = orderItemRepository;
        this.orderRepository = orderRepository;
        this.itemRepository = itemRepository;
    }

    // Add an item to an order
    public Optional<OrderItemDTO> addItemToOrder(OrderItemDTO orderItemDTO) {
        // Create the composite key for OrderItem
        OrderItemKey orderItemKey = new OrderItemKey(orderItemDTO.getOrderId(), orderItemDTO.getItemId());

        Optional<OrderItem> existingOrderItem = orderItemRepository.findById(orderItemKey);

        // Fetch Order and Item entities
        Optional<Order> order = orderRepository.findById(orderItemDTO.getOrderId());
        Optional<Item> item = itemRepository.findById(orderItemDTO.getItemId());

        if (order.isEmpty() || item.isEmpty()) {
            return Optional.empty();  // Return empty if either order or item doesn't exist
        }

        if (existingOrderItem.isPresent()) {
            // If the item already exists, update the quantity
            OrderItem orderItem = existingOrderItem.get();
            orderItem.setQuantity(orderItem.getQuantity() + orderItemDTO.getQuantity());
            orderItemRepository.save(orderItem);
        } else {
            // Create a new order item
            OrderItem newOrderItem = new OrderItem();
            newOrderItem.setId(orderItemKey);
            newOrderItem.setQuantity(orderItemDTO.getQuantity());
            newOrderItem.setOrder(order.get());  // Set the Order entity
            newOrderItem.setItem(item.get());    // Set the Item entity

            orderItemRepository.save(newOrderItem);
        }

        // Return the DTO
        return Optional.of(orderItemDTO);
    }

    // Remove an item from an order
    public Optional<OrderItemDTO> removeItemFromOrder(OrderItemDTO orderItemDTO) {
        OrderItemKey orderItemKey = new OrderItemKey(orderItemDTO.getOrderId(), orderItemDTO.getItemId());

        Optional<OrderItem> orderItemOptional = orderItemRepository.findById(orderItemKey);

        if (orderItemOptional.isPresent()) {
            orderItemRepository.deleteById(orderItemKey);
            return Optional.of(orderItemDTO); // Return the DTO to show item was removed
        }

        return Optional.empty(); // Return empty if the item wasn't found
    }
}
