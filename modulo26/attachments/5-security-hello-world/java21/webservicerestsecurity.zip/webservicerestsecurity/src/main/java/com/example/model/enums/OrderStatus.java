package com.example.model.enums;

/**
 * The `OrderStatus` enum represents the different states an order can have in the system.
 * It defines four possible statuses:
 * <p>
 * - `pending`: The order has been created but not yet processed.
 * - `shipped`: The order has been shipped to the customer.
 * - `delivered`: The order has been successfully delivered to the customer.
 * - `canceled`: The order has been canceled and will not be processed.
 */
public enum OrderStatus {
    pending, shipped, delivered, canceled
}
