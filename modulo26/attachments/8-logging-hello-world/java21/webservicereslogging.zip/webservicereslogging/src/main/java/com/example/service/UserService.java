package com.example.service;

import com.example.dto.user.UserDTO;
import com.example.model.User;
import com.example.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Save or update a User
    public UserDTO saveUser(UserDTO userDTO) {
        logger.info("Saving user: {}", userDTO.getUsername());

        User user = new User();
        user.setUserId(userDTO.getUserId());
        user.setUsername(userDTO.getUsername());
        user.setEmail(userDTO.getEmail());

        User savedUser = userRepository.save(user);

        logger.info("User saved successfully. User ID: {}", savedUser.getUserId());

        return new UserDTO(
                savedUser.getUserId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getCreatedAt().toString()
        );
    }

    // Retrieve a User by ID
    public Optional<UserDTO> getUserById(Integer userId) {
        logger.info("Fetching user by ID: {}", userId);

        Optional<User> user = userRepository.findById(userId);
        if (user.isEmpty()) {
            logger.warn("User not found. User ID: {}", userId);
            return Optional.empty();
        }

        User u = user.get();
        UserDTO userDTO = new UserDTO(u.getUserId(), u.getUsername(), u.getEmail(), u.getCreatedAt().toString());

        logger.info("User fetched successfully. User ID: {}", userDTO.getUserId());

        return Optional.of(userDTO);
    }

    // Retrieve a User by Username
    public Optional<UserDTO> getUserByUsername(String username) {
        logger.info("Fetching user by username: {}", username);

        Optional<User> user = userRepository.findByUsername(username);
        if (user.isEmpty()) {
            logger.warn("User not found. Username: {}", username);
            return Optional.empty();
        }

        User u = user.get();
        UserDTO userDTO = new UserDTO(u.getUserId(), u.getUsername(), u.getEmail(), u.getCreatedAt().toString());

        logger.info("User fetched successfully. Username: {}", userDTO.getUsername());

        return Optional.of(userDTO);
    }

    // Retrieve a User by Email
    public Optional<UserDTO> getUserByEmail(String email) {
        logger.info("Fetching user by email: {}", email);

        Optional<User> user = userRepository.findByEmail(email);
        if (user.isEmpty()) {
            logger.warn("User not found. Email: {}", email);
            return Optional.empty();
        }

        User u = user.get();
        UserDTO userDTO = new UserDTO(u.getUserId(), u.getUsername(), u.getEmail(), u.getCreatedAt().toString());

        logger.info("User fetched successfully. Email: {}", userDTO.getEmail());

        return Optional.of(userDTO);
    }

    // Delete a User by ID
    public void deleteUser(Integer userId) {
        logger.info("Deleting user by ID: {}", userId);

        userRepository.deleteById(userId);

        logger.info("User deleted successfully. User ID: {}", userId);
    }
}
