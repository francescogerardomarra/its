// This is the package declaration, indicating where the class resides in the project
package com.example.endpoint;

// Import necessary classes
import com.example.model.Person; // Import the Person model (entity for database mapping)
import com.example.service.PersonService; // Import the service layer to handle business logic
import com.example.soap.response.GetAllPersonsResponse;
import com.example.soap.request.InsertPersonRequest; // Import the SOAP request model for incoming data
import com.example.soap.response.InsertPersonResponse; // Import the SOAP response model to send back data
import org.springframework.beans.factory.annotation.Autowired; // Import Spring's @Autowired annotation for constructor injection
import org.springframework.ws.server.endpoint.annotation.Endpoint; // Import the @Endpoint annotation to define the SOAP endpoint
import org.springframework.ws.server.endpoint.annotation.PayloadRoot; // Import to define the root element of the SOAP request
import org.springframework.ws.server.endpoint.annotation.RequestPayload; // Import to bind the SOAP request body to method parameters
import org.springframework.ws.server.endpoint.annotation.ResponsePayload; // Import to define the response body for SOAP responses

import java.util.List;
import java.util.stream.Collectors;

/**
 * PersonEndpoint is a SOAP web service endpoint class that handles incoming SOAP requests.
 *
 * The @Endpoint annotation marks this class as a SOAP web service endpoint. This is different
 * from a @RestController in that it handles SOAP requests instead of REST requests, and is designed
 * to work with the XML-based SOAP protocol.
 *
 * The @PayloadRoot annotation is used to define the root element of the incoming SOAP request.
 * This is how the method maps to a specific XML structure in the SOAP message.
 *
 * The Person class is an entity model used for database mapping (e.g., with JPA), and is not
 * directly related to the SOAP request/response mapping. The entity represents the data that is
 * saved to the database, while the SOAP request and response classes are responsible for XML
 * serialization and deserialization.
 */
@Endpoint // Marks this class as a SOAP web service endpoint. Unlike @RestController, @Endpoint is for SOAP services.
public class PersonEndpoint {

    // Define the namespace URI for the SOAP service.
    // This ensures that SOAP messages with the correct namespace are routed to this endpoint.
    // The namespace serves as a unique identifier for the SOAP messages, preventing name conflicts
    // between different services and ensuring that this endpoint processes requests from the correct service.
    // The SOAP request will need to reference the namespace URI (http://example.com/soap) and use the correct element name (in this case, "InsertPersonRequest").
    private static final String NAMESPACE_URI = "http://example.com/soap";

    // Explicit constructor injection for PersonService to handle business logic.
    // This service is responsible for saving Person data to the database.
    private final PersonService personService;

    // Constructor with @Autowired annotation to automatically inject the PersonService into this class
    @Autowired
    public PersonEndpoint(PersonService personService) {
        this.personService = personService; // Assign injected service to the instance variable
    }

    /**
     * This method is mapped to the 'InsertPersonRequest' SOAP message.
     * The @PayloadRoot annotation binds this method to the incoming SOAP request with the given namespace and local part.
     * It means that this method will handle SOAP requests with the localPart "InsertPersonRequest" in the specified namespace.
     *
     * @PayloadRoot(namespace = NAMESPACE_URI, localPart = "InsertPersonRequest") means that this method listens to
     * SOAP messages with this exact structure in the XML.
     *
     * The namespace ensures that this method will only handle SOAP requests related to the specified service,
     * avoiding conflicts with other services that may use similar element names in their XML structure.
     *
     * @RequestPayload: This annotation is used to bind the incoming SOAP request body to the method parameter (in this case, 'request').
     * Underneath, Spring Web Services automatically deserializes the XML payload from the SOAP message and maps it
     * into the 'InsertPersonRequest' Java object. This deserialization happens transparently, so the 'request' parameter is
     * populated with the corresponding values from the XML body (e.g., name, surname, city, and age).
     *
     * @ResponsePayload: This annotation indicates that the method will return a SOAP response body. The response object
     * will be serialized into XML format, and Spring Web Services handles this serialization automatically.
     * In this case, the 'InsertPersonResponse' object will be converted into a SOAP XML response and sent back to the client.
     * This makes it easy to return complex objects as part of a SOAP response without manually converting them to XML.
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "InsertPersonRequest") // The method is mapped to the InsertPersonRequest SOAP message
    @ResponsePayload // The method will return a SOAP response, to be serialized into XML
    public InsertPersonResponse addPerson(@RequestPayload InsertPersonRequest request) {
        // Create a new Person entity and populate its fields from the SOAP request
        Person person = new Person();
        person.setName(request.getName()); // Set the name of the person from the SOAP request
        person.setSurname(request.getSurname()); // Set the surname of the person from the SOAP request
        person.setCity(request.getCity()); // Set the city of the person from the SOAP request
        person.setAge(request.getAge()); // Set the age of the person from the SOAP request

        // Save the new person object to the database using the PersonService
        personService.savePerson(person); // Calls the service layer to persist the Person entity

        // Create a SOAP response object to return to the client
        InsertPersonResponse response = new InsertPersonResponse();
        response.setMessage("Person added successfully!"); // Set the success message in the response

        // Return the populated response object, which will be serialized into a SOAP response
        return response; // Sends the response back to the client in SOAP format
    }

    /**
     * This method handles the retrieval of all persons.
     * It is mapped to the 'GetAllPersonsRequest' SOAP message, which will trigger this method when requested.
     *
     * @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetAllPersonsRequest") ensures that this method
     * listens to incoming SOAP requests with the specified namespace and local part ("GetAllPersonsRequest").
     * This namespace uniquely identifies the service and avoids conflicts with other services that may have similar
     * element names in their XML messages. The method is executed when a SOAP request with this structure is received.
     *
     * @ResponsePayload: This annotation is used to mark the return value of the method as the SOAP response body.
     * Underneath, Spring Web Services automatically serializes the response object (in this case, 'GetAllPersonsResponse')
     * into XML format. This means that you don't need to manually convert the 'GetAllPersonsResponse' object into XML;
     * Spring handles this serialization automatically, making it easy to return complex objects as part of a SOAP response.
     *
     * Note: While this method doesn't use @RequestPayload (since it doesn't require any request data in the body),
     * if it had, the XML request body would be deserialized into a corresponding Java object automatically by Spring.
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetAllPersonsRequest") // This method is mapped to the SOAP request 'GetAllPersonsRequest' with the defined namespace
    @ResponsePayload // The method will return a SOAP response that will be serialized into XML format
    public GetAllPersonsResponse getAllPersons() {
        // Step 1: Retrieve all persons from the service layer
        // Here we use the personService to get all the persons from the database (or any data source).
        // The service is responsible for the logic of fetching the persons.
        List<Person> persons = personService.getAllPersons();

        // Step 2: Create a new response object to hold the list of InsertPersonResponse objects
        // The response will be serialized into XML to send back to the client. This will hold all the person data.
        GetAllPersonsResponse response = new GetAllPersonsResponse();

        // Step 3: Convert each Person entity into a InsertPersonResponse object
        // Since the SOAP response format requires a specific structure, we map each Person entity
        // to a InsertPersonResponse. InsertPersonResponse contains a message property to display basic person info.
        List<InsertPersonResponse> InsertPersonResponses = persons.stream()
                .map(person -> {
                    // Step 4: Create a new InsertPersonResponse for each Person entity
                    // Here we create a new InsertPersonResponse object and populate it with data from the Person entity.
                    InsertPersonResponse InsertPersonResponse = new InsertPersonResponse();

                    // Step 5: Set the message with all the fields (name, surname, city, and age)
                    String fullMessage = String.format("Person: %s %s, City: %s, Age: %d",
                            person.getName(), person.getSurname(), person.getCity(), person.getAge());
                    InsertPersonResponse.setMessage(fullMessage); // Set the full message

                    return InsertPersonResponse; // Return the InsertPersonResponse object for this person
                })
                .collect(Collectors.toList()); // Collect all the mapped InsertPersonResponse objects into a list

        // Step 6: Set the list of InsertPersonResponse objects into the response object
        // The GetAllPersonsResponse object holds a list of InsertPersonResponse objects, which is returned to the client.
        response.setPersons(InsertPersonResponses);

        // Step 7: Return the response
        // This will be automatically converted into a SOAP XML response and sent back to the client.
        return response;
    }
}