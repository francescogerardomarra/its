package com.example.service;

import com.example.dto.item.ItemDTO;
import com.example.model.Item;
import com.example.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    // Create or update an Item
    public ItemDTO saveItem(ItemDTO itemDTO) {
        Item item = new Item();
        item.setItemId(itemDTO.getItemId());
        item.setName(itemDTO.getName());
        item.setDescription(itemDTO.getDescription());
        item.setPrice(BigDecimal.valueOf(itemDTO.getPrice()));
        item.setStockQuantity(itemDTO.getStockQuantity() == null ? 0 : itemDTO.getStockQuantity());

        Item savedItem = itemRepository.save(item);

        return new ItemDTO(
                savedItem.getItemId(),
                savedItem.getName(),
                savedItem.getDescription(),
                savedItem.getPrice().doubleValue(),
                savedItem.getStockQuantity()
        );
    }

    // Retrieve all Items
    public List<ItemDTO> getAllItems() {
        return itemRepository.findAll().stream()
                .map(item -> new ItemDTO(
                        item.getItemId(),
                        item.getName(),
                        item.getDescription(),
                        item.getPrice().doubleValue(),
                        item.getStockQuantity()
                ))
                .collect(Collectors.toList());
    }

    // Retrieve an Item by ID
    public Optional<ItemDTO> getItemById(Integer itemId) {
        return itemRepository.findById(itemId).map(item -> new ItemDTO(
                item.getItemId(),
                item.getName(),
                item.getDescription(),
                item.getPrice().doubleValue(),
                item.getStockQuantity()
        ));
    }

    // Retrieve items by price range using the native query
    public List<ItemDTO> getItemsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        return itemRepository.findItemsByPriceRange(minPrice, maxPrice).stream()
                .map(item -> new ItemDTO(
                        item.getItemId(),
                        item.getName(),
                        item.getDescription(),
                        item.getPrice().doubleValue(),
                        item.getStockQuantity()
                ))
                .collect(Collectors.toList());
    }


    // Delete an Item by ID
    public void deleteItem(Integer itemId) {
        itemRepository.deleteById(itemId);
    }
}
