package com.example.rest.response.user;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Response class for retrieving User details.
 * Used for:
 * - GET requests to retrieve a User;
 * - response when sending a POST or PUT request to create or modify a User.
 */
@Getter
@Setter
@AllArgsConstructor
public class UserResponse {

    @JsonProperty("user_id")
    private Integer userId;

    @JsonProperty("username")
    private String username;

    @JsonProperty("email")
    private String email;

    @JsonProperty("created_at")
    private String createdAt; // Represented as a String for easy JSON formatting
}
