package com.example.rest.response.order;

import com.example.model.OrderItem;
import com.example.model.enums.OrderStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response class for retrieving Order details.
 * Used for:
 * - GET requests to retrieve an Order;
 * - response when sending a POST request to create a new Order.
 */
@Getter
@Setter
@AllArgsConstructor
public class OrderResponse {

    @JsonProperty("order_id")
    private Integer orderId;

    @JsonProperty("order_date")
    private LocalDateTime orderDate;

    @JsonProperty("status")
    private OrderStatus status;

    @JsonProperty("user_id")
    private Integer userId;

    @JsonProperty("order_items")
    private List<OrderItem> orderItems;
}
