package com.example.config; // Defines the package where this class belongs

// Import necessary Spring and Spring-WS classes

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.ws.wsdl.wsdl11.Wsdl11Definition;

/**
 * WebServiceConfig is a configuration class for setting up the SOAP web service in a Spring Boot application.
 * It registers the MessageDispatcherServlet, which is responsible for handling incoming SOAP requests and routing them
 * to the appropriate endpoint.
 */
@Configuration // Marks this class as a Spring configuration class, enabling Spring to detect and use it
@EnableWs // Enables Spring Web Services support (necessary for SOAP web services)
public class WebServiceConfig {

    /**
     * Registers the MessageDispatcherServlet, which processes SOAP requests.
     *
     * @param applicationContext The Spring application context, automatically injected by Spring
     * @return A ServletRegistrationBean that registers the servlet and maps it to a specific URL pattern
     */
    @Bean // Marks this method as a Spring-managed bean, allowing Spring to initialize and manage it
    public ServletRegistrationBean<MessageDispatcherServlet> messageDispatcherServlet(ApplicationContext applicationContext) {
        // Create an instance of MessageDispatcherServlet, which is responsible for handling SOAP requests
        MessageDispatcherServlet servlet = new MessageDispatcherServlet();

        // Set the application context so that the servlet can find the Spring-managed SOAP endpoints
        servlet.setApplicationContext(applicationContext);

        // Ensures that WSDL file locations in responses are correctly transformed to match the request URL
        servlet.setTransformWsdlLocations(true);

        // Registers the servlet and maps it to handle requests at "/ws/*"
        // This means all SOAP requests should be sent to URLs starting with "/ws/"
        return new ServletRegistrationBean<>(servlet, "/ws/*");
    }
}
