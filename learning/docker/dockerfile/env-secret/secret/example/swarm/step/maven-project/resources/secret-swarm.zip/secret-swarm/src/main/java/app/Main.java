package app;

import swarm.SecretManager;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        String secret = SecretManager.getSecret("test-secret");

        System.out.println("[Main] secret: " + secret);

        // this code prevents the Docker Swarm service from stopping immediately;
        // without a running process, the container would exit,
        // and depending on the Swarm service configuration, it may restart or stop permanently.
        while (true){
            Thread.sleep(50000);
        }

    }
}
