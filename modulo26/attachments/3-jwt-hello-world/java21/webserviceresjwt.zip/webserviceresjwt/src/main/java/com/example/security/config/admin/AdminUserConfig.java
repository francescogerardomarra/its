package com.example.security.config.admin;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

/**
 * Configuration class to set up an in-memory user store for an admin user.
 *
 * This configuration class creates an in-memory `UserDetailsService` to store and manage the details
 * of the admin user. It uses the username and password defined in the application's properties file.
 *
 * The password is encoded using a `PasswordEncoder` before being stored, and the admin user will be
 * authenticated using this in-memory configuration.
 */
@Configuration  // Marks this class as a source of bean definitions for the application context.
public class AdminUserConfig {

    @Value("${admin.username}")
    private String adminUsername;  // The admin username is fetched from the application's properties.

    @Value("${admin.password}")
    private String adminPassword;  // The admin password is fetched from the application's properties.

    /**
     * Bean configuration for the `UserDetailsService` used to load the admin user details.
     * This bean is responsible for loading user-specific data, such as username and password, for authentication.
     * We configure the `InMemoryUserDetailsManager` here for simplicity and to avoid needing a persistent storage solution.
     * It provides a user repository that is kept in memory, which is useful for simple scenarios like testing or small apps.
     *
     * The `UserDetailsService` interface is central to Spring Security's authentication process. In this case, we are using it
     * to load the admin user from in-memory storage and apply password encoding with `PasswordEncoder` to securely store
     * the password.
     *
     * @param passwordEncoder The `PasswordEncoder` bean used to encode the admin user's password before storing it.
     * @return A `UserDetailsService` instance that Spring Security will use to load the admin user during authentication.
     */
    @Bean
    public UserDetailsService adminUserDetailsService(PasswordEncoder passwordEncoder) {
        // Create the admin user in memory with a username and encoded password.
        return new InMemoryUserDetailsManager(
                User.withUsername(adminUsername)  // Set the admin username.
                        .password(passwordEncoder.encode(adminPassword))  // Encode the password before storing it.
                        .build()  // Build and return the UserDetails object for the admin user.
        );
    }
}
