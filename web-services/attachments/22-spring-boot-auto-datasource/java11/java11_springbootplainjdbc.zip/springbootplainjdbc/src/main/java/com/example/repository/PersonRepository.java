package com.example.repository;

import com.example.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Repository
public class PersonRepository {
    private final DataSource dataSource;

    @Autowired // Explicitly declare constructor injection
    public PersonRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void addPerson(Person person) {
        String sql = "INSERT INTO my_schema.person (name, surname, city, age) VALUES (?, ?, ?, ?)";
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, person.getName());
            statement.setString(2, person.getSurname());
            statement.setString(3, person.getCity());
            statement.setInt(4, person.getAge());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
