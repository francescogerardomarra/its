package com.example.dto.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class UserDTO {

    private Integer userId;
    private String username;
    private String email;
    private String createdAt;  // Represented as a String for easy JSON formatting
}