package com.example.service;

import com.example.model.User;
import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Create or update a User
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // Retrieve all Users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Retrieve a User by ID
    public Optional<User> getUserById(Integer userId) {
        return userRepository.findById(userId);
    }

    // Retrieve a User by Username
    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Retrieve a User by Email
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Delete a User by ID
    public void deleteUser(Integer userId) {
        userRepository.deleteById(userId);
    }
}
