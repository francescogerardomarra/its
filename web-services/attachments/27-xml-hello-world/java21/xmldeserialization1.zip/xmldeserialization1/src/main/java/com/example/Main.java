package com.example;

public class Main {
    public static void main(String[] args) {
        try {
            // Define the paths to well-formed and malformed XML files
            String wellFormedXML = "src/main/resources/person.xml";  // Path to a valid XML file
            String malformedXML = "src/main/resources/invalid_person.xml";  // Path to an invalid XML file

            // Deserialize well-formed XML using XMLHandler
            // This will try to convert the XML into a Person object
            Person person = XMLHandler.deserializeFromXML(wellFormedXML);

            // If deserialization is successful, print the name and age of the Person object
            System.out.println("SUCCESS - Deserialized Person: " + person.getName() + ", Age: " + person.getAge());

            // Attempt to deserialize malformed XML, which is expected to fail
            try {
                // Try deserializing the invalid XML file
                Person invalidPerson = XMLHandler.deserializeFromXML(malformedXML);

                // If deserialization succeeds (which shouldn't happen), print the details
                System.out.println("SUCCESS - Deserialized Invalid Person: " + invalidPerson.getName() + ", Age: " + invalidPerson.getAge());
            } catch (Exception e) {
                // Catch any exception that occurs during deserialization of malformed XML
                // If it fails, print an error message with the exception details
                System.err.println("FAILURE - Failed to deserialize malformed XML: " + e.getMessage());
            }
        } catch (Exception e) {
            // Catch any unexpected errors that occur during the entire process
            // This handles general deserialization failures
            System.err.println("FAILURE - Error during deserialization: " + e.getMessage());
        }
    }
}