package com.example.backend.service;

import com.example.backend.entity.Text;
import com.example.backend.repository.TextRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TextService {

    private final TextRepository textRepository;

    @Autowired
    public TextService(TextRepository textRepository) {
        this.textRepository = textRepository;
    }

    public List<String> findAll() {
        List<Text> result = textRepository.findAll();

        List<String> stringList = result.stream()
                .map(text -> text.getValue())
                .toList();

        return stringList;
    }

    public void save(String value) {
        Text text = new Text();

        text.setValue(value);
        textRepository.save(text);
    }
}
