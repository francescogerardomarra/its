package com.example.rest.response.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Response class for retrieving Item details.
 * Used for:
 * - GET requests to retrieve an Item;
 * - response when sending a POST or PUT request to create or modify an Item.
 */
@Getter
@Setter
@AllArgsConstructor
public class ItemResponse {

    @JsonProperty("item_id")
    private Integer itemId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @JsonProperty("price")
    private Double price;

}
