package com.example.controller;

import com.example.dto.order.OrderDTO;
import com.example.dto.order.OrderStatusDTO;
import com.example.model.enums.OrderStatus;
import com.example.rest.request.order.OrderRequest;
import com.example.rest.request.order.RemoveOrderRequest;
import com.example.rest.response.RemoveOrderResponse;
import com.example.rest.response.order.OrderResponse;
import com.example.service.OrderService;
import com.example.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/shop/orders")
public class OrderController {

    private final OrderService orderService;
    private final UserService userService;

    @Autowired
    public OrderController(OrderService orderService, UserService userService) {
        this.orderService = orderService;
        this.userService = userService;
    }

    // Create a new order (without items initially)
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@RequestBody @Valid OrderRequest orderRequest) {
        // Pass the DTO to the service
        OrderDTO orderDTO = new OrderDTO(
                null, // orderId is not set for new orders
                null, // orderDate is set in the service layer
                null, // status is set in the service layer
                orderRequest.getUserId(), // The userId from the request
                null // No items in the order initially
        );

        Optional<OrderDTO> savedOrder = orderService.saveOrder(orderDTO);

        // Check if the order was saved and return appropriate response
        if (savedOrder.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        // Manually map fields from OrderDTO to OrderResponse
        OrderDTO savedOrderDTO = savedOrder.get();
        OrderResponse response = new OrderResponse(
                savedOrderDTO.getOrderId(),
                savedOrderDTO.getOrderDate(),
                savedOrderDTO.getStatus(),
                savedOrderDTO.getUserId(),
                savedOrderDTO.getOrderItems()
        );

        return ResponseEntity.status(201).body(response);
    }

    // Retrieve an order by its ID with explicit parameter
    @GetMapping(params = "orderId")
    public ResponseEntity<OrderResponse> getOrderById(@RequestParam Integer orderId) {
        Optional<OrderDTO> orderDTO = orderService.getOrderById(orderId);

        // If the order doesn't exist, return a 404 response
        if (orderDTO.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Manually map fields from OrderDTO to OrderResponse
        OrderDTO orderDTOResponse = orderDTO.get();
        OrderResponse response = new OrderResponse(
                orderDTOResponse.getOrderId(),
                orderDTOResponse.getOrderDate(),
                orderDTOResponse.getStatus(),
                orderDTOResponse.getUserId(),
                orderDTOResponse.getOrderItems() // Map order items if necessary
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve orders by user ID
    @GetMapping(params = "userId")
    public ResponseEntity<List<OrderResponse>> getOrdersByUserId(@RequestParam Integer userId) {
        List<OrderDTO> ordersDTO = orderService.getOrdersByUserId(userId);

        if (ordersDTO.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Manually map List<OrderDTO> to List<OrderResponse>
        List<OrderResponse> responses = ordersDTO.stream()
                .map(orderDTO -> new OrderResponse(
                        orderDTO.getOrderId(),
                        orderDTO.getOrderDate(),
                        orderDTO.getStatus(),
                        orderDTO.getUserId(),
                        orderDTO.getOrderItems()
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    /**
     * Retrieve orders by status.
     *
     * @param status The status of the orders to retrieve.
     * @return A list of orders with the specified status.
     */
    @GetMapping(params = "status")
    public ResponseEntity<List<OrderStatusDTO>> getOrdersByStatus(@RequestParam OrderStatus status) {
        try {
            List<OrderStatusDTO> orders = orderService.getOrdersByStatus(status);

            if (orders.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            return ResponseEntity.ok(orders);
        } catch (DataAccessException e) {
            return ResponseEntity.internalServerError().build(); // Database-related error
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null); // Unexpected error
        }
    }

    // Delete an order by its ID
    @DeleteMapping
    public ResponseEntity<RemoveOrderResponse> deleteOrder(@RequestBody @Valid RemoveOrderRequest request) {
        Optional<OrderDTO> orderDTO = orderService.getOrderById(request.getOrderId());

        if (orderDTO.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        orderService.deleteOrder(request.getOrderId());

        RemoveOrderResponse response = new RemoveOrderResponse(
                request.getOrderId(),
                "Order deleted successfully"
        );

        return ResponseEntity.ok(response);
    }
}
