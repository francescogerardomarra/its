package com.example;  // Specifies the package in which this class belongs

import com.fasterxml.jackson.databind.ObjectMapper;  // Imports ObjectMapper for deserializing JSON into Java objects
import org.everit.json.schema.Schema;  // Imports the Schema class for validating JSON schema
import org.everit.json.schema.loader.SchemaLoader;  // Imports SchemaLoader for loading a JSON schema
import org.json.JSONObject;  // Imports JSONObject to work with JSON objects
import org.json.JSONTokener;  // Imports JSONTokener for parsing JSON input
import java.io.File;  // Imports File class for file handling (although not used here)
import java.io.FileInputStream;  // Imports FileInputStream for reading files as input streams
import java.io.IOException;  // Imports IOException for handling input/output exceptions

public class JsonHandler {  // Declares a class named JsonHandler
    // A static method to validate and deserialize a JSON file based on a schema
    public static Person validateAndDeserialize(String jsonFilePath, String schemaFilePath) throws IOException {

        // Open both the schema file and the JSON file as input streams using try-with-resources
        try (FileInputStream schemaStream = new FileInputStream(schemaFilePath);
             FileInputStream jsonStream = new FileInputStream(jsonFilePath)) {

            // Create a JSONObject from the schema file using JSONTokener to parse the input stream
            JSONObject rawSchema = new JSONObject(new JSONTokener(schemaStream));

            // Load the schema using SchemaLoader
            Schema schema = SchemaLoader.load(rawSchema);

            // Create a JSONObject from the JSON data file using JSONTokener to parse the input stream
            JSONObject jsonData = new JSONObject(new JSONTokener(jsonStream));

            // Validate the JSON data against the loaded schema
            schema.validate(jsonData);

            // Create an ObjectMapper to handle JSON deserialization
            ObjectMapper objectMapper = new ObjectMapper();

            // Deserialize the JSON data into a Person object
            Person person = objectMapper.readValue(jsonData.toString(), Person.class);

            // Output the result of deserialization, showing the details of the Person object
            System.out.println("SUCCESS - Deserialized Person: " + person.getName() + ", Age: " + person.getAge() + ", Email: " + person.getEmail());

            return person;
        }
    }
}