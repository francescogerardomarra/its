package com.example;

public class Main {
    public static void main(String[] args) {
        try {
            // Define the paths to the valid and invalid XML files, and the schema
            String validXML = "src/main/resources/person_valid.xml";
            String invalidXML = "src/main/resources/person_invalid.xml";
            String schemaPath = "src/main/resources/person.xsd";

            // Without validation - Deserialize the valid XML file without any validation
            Person person1 = XMLHandler.deserializeWithoutValidation(validXML);
            // Print the details of the person object after deserialization (including email)
            System.out.println("SUCCESS - validXML deserialized without validation: " +
                    person1.getName() + ", Age: " + person1.getAge() + ", Email: " + person1.getEmail());

            // With validation (valid XML) - Deserialize the valid XML file with validation using the schema
            Person person2 = XMLHandler.deserializeWithValidation(validXML, schemaPath);
            // Print the details of the person object after deserialization (including email)
            System.out.println("SUCCESS - validXML deserialized with validation: " +
                    person2.getName() + ", Age: " + person2.getAge() + ", Email: " + person2.getEmail());

            // With validation (invalid XML) - Attempt to deserialize the invalid XML with validation
            try {
                Person person3 = XMLHandler.deserializeWithValidation(invalidXML, schemaPath);
            } catch (Exception e) {
                // Print error message when deserialization fails due to invalid XML
                System.err.println("FAILURE - Failed to deserialize invalid XML: " + e.getMessage());
            }
        } catch (Exception e) {
            // Handle and print any general exceptions during execution
            e.printStackTrace();
        }
    }
}