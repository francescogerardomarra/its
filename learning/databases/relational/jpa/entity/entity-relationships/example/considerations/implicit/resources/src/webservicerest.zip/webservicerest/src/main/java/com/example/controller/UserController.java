package com.example.controller;

import com.example.model.User;
import com.example.rest.request.user.RemoveUserRequest;
import com.example.rest.request.user.UserRequest;
import com.example.rest.response.user.RemoveUserResponse;
import com.example.rest.response.user.UserResponse;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

@RestController
@RequestMapping("/shop/users")  // Base path for user-related operations
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Create a new user
    @PostMapping
    public ResponseEntity<UserResponse> createUser(@RequestBody UserRequest userRequest) {
        User user = new User();
        user.setUsername(userRequest.getUsername());
        user.setEmail(userRequest.getEmail());

        User savedUser = userService.saveUser(user);

        UserResponse response = new UserResponse(
                savedUser.getUserId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME)
        );

        return ResponseEntity.ok(response);
    }

    // Modify an existing user (update username and/or email)
    @PutMapping
    public ResponseEntity<UserResponse> updateUser(@RequestBody UserRequest userRequest) {

        Optional<User> existingUser = userService.getUserByEmail(userRequest.getEmail());
        if (existingUser.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        User user = existingUser.get();
        user.setUsername(userRequest.getUsername());
        user.setEmail(userRequest.getEmail());

        User updatedUser = userService.saveUser(user);

        UserResponse response = new UserResponse(
                updatedUser.getUserId(),
                updatedUser.getUsername(),
                updatedUser.getEmail(),
                updatedUser.getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME)
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve user by ID (query parameter)
    @GetMapping(params = "id")
    public ResponseEntity<UserResponse> getUserById(@RequestParam Integer id) {
        Optional<User> user = userService.getUserById(id);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME)
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve user by email (query parameter)
    @GetMapping(params = "email")
    public ResponseEntity<UserResponse> getUserByEmail(@RequestParam String email) {
        Optional<User> user = userService.getUserByEmail(email);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME)
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve user by username (query parameter)
    @GetMapping(params = "username")
    public ResponseEntity<UserResponse> getUserByUsername(@RequestParam String username) {
        Optional<User> user = userService.getUserByUsername(username);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt().format(DateTimeFormatter.ISO_DATE_TIME)
        );

        return ResponseEntity.ok(response);
    }

    // Remove a user (delete)
    @DeleteMapping
    public ResponseEntity<RemoveUserResponse> deleteUser(@RequestBody RemoveUserRequest request) {
        Optional<User> user = userService.getUserById(request.getUserId());
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        userService.deleteUser(request.getUserId());

        RemoveUserResponse response = new RemoveUserResponse(
                request.getUserId(),
                "User deleted successfully"
        );

        return ResponseEntity.ok(response);
    }
}
