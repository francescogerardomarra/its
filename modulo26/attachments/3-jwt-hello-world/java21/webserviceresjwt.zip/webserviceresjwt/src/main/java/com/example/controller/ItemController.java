package com.example.controller;

import com.example.dto.item.ItemDTO;
import com.example.rest.request.item.ItemRequest;
import com.example.rest.response.item.ItemResponse;
import com.example.service.ItemService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/shop/items")  // Base path for all item-related endpoints
public class ItemController {

    private final ItemService itemService;

    @Autowired
    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    // Create a new item
    @PostMapping  // Method-level mapping
    public ResponseEntity<ItemResponse> createItem(@RequestBody @Valid ItemRequest itemRequest) {
        ItemDTO itemDTO = new ItemDTO(
                null, // Item ID is not needed for creation
                itemRequest.getName(),
                itemRequest.getDescription(),
                itemRequest.getPrice(),
                0 // Default stock quantity
        );

        ItemDTO savedItemDTO = itemService.saveItem(itemDTO);

        // Creating the response
        ItemResponse response = new ItemResponse(
                savedItemDTO.getItemId(),
                savedItemDTO.getName(),
                savedItemDTO.getDescription(),
                savedItemDTO.getPrice(),
                savedItemDTO.getStockQuantity()
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve an item by its ID
    @GetMapping("/{itemId}")  // Method-level mapping with path variable
    public ResponseEntity<ItemResponse> getItemById(@PathVariable Integer itemId) {
        Optional<ItemDTO> itemDTO = itemService.getItemById(itemId);
        if (itemDTO.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Creating the response
        ItemResponse response = new ItemResponse(
                itemDTO.get().getItemId(),
                itemDTO.get().getName(),
                itemDTO.get().getDescription(),
                itemDTO.get().getPrice(),
                itemDTO.get().getStockQuantity()
        );

        return ResponseEntity.ok(response);
    }

    // Modify an existing item (update name, description, and price)
    @PutMapping("/{itemId}")  // Method-level mapping with path variable
    public ResponseEntity<ItemResponse> updateItem(@PathVariable Integer itemId, @RequestBody @Valid ItemRequest itemRequest) {
        Optional<ItemDTO> existingItemDTO = itemService.getItemById(itemId);
        if (existingItemDTO.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        ItemDTO itemDTO = existingItemDTO.get();
        if (itemRequest.getName() != null) itemDTO.setName(itemRequest.getName());
        if (itemRequest.getDescription() != null) itemDTO.setDescription(itemRequest.getDescription());
        if (itemRequest.getPrice() != null) itemDTO.setPrice(itemRequest.getPrice());

        ItemDTO updatedItemDTO = itemService.saveItem(itemDTO);

        // Creating the response
        ItemResponse response = new ItemResponse(
                updatedItemDTO.getItemId(),
                updatedItemDTO.getName(),
                updatedItemDTO.getDescription(),
                updatedItemDTO.getPrice(),
                updatedItemDTO.getStockQuantity()
        );

        return ResponseEntity.ok(response);
    }
}
