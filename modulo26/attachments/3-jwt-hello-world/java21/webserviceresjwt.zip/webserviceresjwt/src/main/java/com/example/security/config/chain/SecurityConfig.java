package com.example.security.config.chain;

import com.example.security.jwt.filter.TokenAuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Configuration class for HTTP security, defining two separate security chains.
 * One chain is for Basic Authentication used for login, and another is for JWT Authentication
 * applied to the protected resources.
 *
 * The two chains are ordered to provide specific security configurations for different parts of the application:
 * - **Basic Authentication** for login (`/shop/login` endpoint).
 * - **JWT Authentication** for the remaining protected endpoints (`/shop/users`, `/shop/items`).
 *
 * Flow:
 * 1. Basic Authentication is applied to login requests, where users authenticate and receive a JWT token.
 * 2. JWT Authentication is then applied to further protected endpoints using the `TokenAuthenticationFilter`.
 */
@Configuration
@EnableWebSecurity  // Enables Spring Security's web security configuration
public class SecurityConfig {

    private final TokenAuthenticationFilter tokenAuthenticationFilter;

    /**
     * Constructor to inject the custom TokenAuthenticationFilter.
     * This filter is responsible for validating JWT tokens in requests.
     */
    @Autowired
    public SecurityConfig(TokenAuthenticationFilter tokenAuthenticationFilter) {
        this.tokenAuthenticationFilter = tokenAuthenticationFilter;
    }

    /**
     * Configures the first security filter chain for Basic Authentication.
     * This filter chain applies only to the `/shop/login` endpoint, allowing authentication via Basic Auth.
     *
     * - Only the `/shop/login` endpoint is secured with Basic Authentication.
     * - Once the user authenticates successfully, they will receive a JWT token to use for future requests.
     * - The session is stateless, meaning no session is stored on the server.
     *
     * The `AuthenticationManager` bean plays a critical role here by validating the user credentials during the Basic Authentication process.
     * Spring Security uses the `AuthenticationManager` to authenticate the user based on the `Authorization` header sent with the request.
     * The authentication process checks the provided username and password against the user details, ensuring that the requestor has valid credentials.
     *
     * If authentication is successful, the user is granted access to the `/shop/login` endpoint, and a JWT token is issued for further requests.
     *
     * @param http The HttpSecurity object used to configure security settings.
     * @return The configured SecurityFilterChain for Basic Authentication.
     * @throws Exception if there are errors in configuring HTTP security.
     */
    @Bean
    @Order(1)  // The first security chain with a higher priority (lower order).
    public SecurityFilterChain basicAuthFilterChain(HttpSecurity http) throws Exception {
        http
                .securityMatcher("/shop/login")  // Apply this filter chain only to the /shop/login endpoint.
                .authorizeHttpRequests(authz -> authz
                        .anyRequest().authenticated()  // Require authentication for this endpoint.
                )
                .httpBasic(Customizer.withDefaults())  // Enable Basic Authentication.
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))  // Stateless session policy.
                .csrf(AbstractHttpConfigurer::disable);  // Disable CSRF as we are using stateless authentication.

        return http.build();  // Build and return the configured filter chain.
    }

    /**
     * Configures the second security filter chain for JWT Authentication.
     * This filter chain applies to the `/shop/users` and `/shop/items` endpoints, which require a valid JWT.
     *
     * - Requests to `/shop/users` and `/shop/items` are protected and require JWT authentication.
     * - Any other request that doesn't match these endpoints is allowed without authentication.
     * - The `TokenAuthenticationFilter` is added to process and validate the JWT token in the Authorization header.
     *
     * The `AuthenticationManager` is implicitly involved in this filter chain as part of the overall authentication process.
     * When a request is made to `/shop/users` or `/shop/items`, the `TokenAuthenticationFilter` extracts the JWT from the `Authorization` header
     * and validates it. If the token is valid, the user is authenticated, and the request proceeds.
     * If no valid token is provided or the token is invalid, the request will be rejected based on the configured security filters.
     *
     * The `AuthenticationManager` is essential here for validating the user’s credentials once the token is parsed. It also helps in
     * setting up the authentication context, ensuring the user is authorized to access these endpoints with the valid JWT.
     *
     * @param http The HttpSecurity object used to configure security settings.
     * @return The configured SecurityFilterChain for JWT Authentication.
     * @throws Exception if there are errors in configuring HTTP security.
     */
    @Bean
    @Order(2)  // The second security chain with lower priority (higher order).
    public SecurityFilterChain jwtFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authz -> authz
                        .requestMatchers("/shop/users", "/shop/items").authenticated()  // Protect these endpoints with JWT authentication.
                        .anyRequest().permitAll()  // Allow all other requests without authentication.
                )
                .addFilterBefore(tokenAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)  // Add the custom JWT filter before the default authentication filter.
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))  // Stateless session policy.
                .csrf(AbstractHttpConfigurer::disable);  // Disable CSRF as we're using stateless authentication.

        return http.build();  // Build and return the configured filter chain.
    }

    /**
     * Bean configuration for `PasswordEncoder`.
     * This bean is used to securely encode and verify user passwords during authentication processes.
     * It is typically used when creating users (e.g., during registration) and when validating passwords during login.
     *
     * In this case, we use `BCryptPasswordEncoder`, a widely used hashing algorithm, to securely hash passwords.
     * BCrypt is designed to be computationally expensive, which makes it resistant to brute force and rainbow table attacks.
     *
     * The `PasswordEncoder` bean is used by Spring Security during authentication, particularly in conjunction with the
     * `UserDetailsService`. It is essential for encoding passwords before storing them and validating them during the
     * authentication process.
     *
     * @return A `BCryptPasswordEncoder` instance that Spring Security will use for encoding and verifying passwords.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        // Use BCrypt for password hashing. BCrypt is a strong algorithm for password encryption.
        return new BCryptPasswordEncoder();
    }

    /**
     * Bean configuration for the `AuthenticationManager`.
     * This bean is responsible for handling the authentication of users, ensuring their credentials are valid.
     * The `AuthenticationManager` is used to process authentication requests for both Basic Authentication and JWT Authentication.
     *
     * When no specific `AuthenticationManager` bean is provided, Spring Security will automatically create a default one
     * based on the configurations set in the `HttpSecurity` object. The default `AuthenticationManager` works with the
     * default `AuthenticationProvider` that handles username/password authentication (such as basic authentication).
     *
     * In this case, we explicitly define an `AuthenticationManager` using the `HttpSecurity` object. This ensures that
     * the `AuthenticationManager` is configured to support our custom authentication flow, including any specific settings
     * for JWT or Basic Authentication, and works properly with our filter chains and security configuration.
     * This explicit configuration guarantees that the `AuthenticationManager` will work seamlessly with the filters
     * (e.g., `TokenAuthenticationFilter`) added to the security chain.
     *
     * The `AuthenticationManager` plays a crucial role in the authentication process and is invoked by various security
     * filters, such as the ones for Basic Authentication and JWT Authentication. For example, during Basic Authentication,
     * it is responsible for validating the credentials provided in the `Authorization` header, while during JWT Authentication,
     * it verifies the validity of the JWT token.
     *
     * @param http The `HttpSecurity` object used to configure various security settings, including authentication and authorization.
     * It defines the security filters and how they should interact with requests.
     * @return The `AuthenticationManager` instance used for authenticating users during login and throughout the application’s
     * security filters.
     * @throws Exception if there are any issues with configuring HTTP security or initializing the `AuthenticationManager`.
     */
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        // Retrieve the shared AuthenticationManager from the HttpSecurity object to ensure it's correctly configured
        // with the customized security settings and filters.
        return http.getSharedObject(AuthenticationManager.class);
    }
}
