package com.example;

import jakarta.xml.bind.JAXBContext; // Import JAXBContext to work with the JAXB API for marshalling and unmarshalling
import jakarta.xml.bind.JAXBException; // Import JAXBException to handle errors related to XML processing
import jakarta.xml.bind.Marshaller; // Import Marshaller for converting Java objects to XML (serialization)
import java.io.File; // Import File to specify where to store the serialized XML file

public class XMLHandler {

    // This method serializes a Person object into an XML file at the specified file path
    public static void serializeToXML(Person person, String filePath) throws JAXBException {
        // Create a JAXBContext for the Person class to enable marshalling (serialization) operations
        JAXBContext context = JAXBContext.newInstance(Person.class);

        // Create a Marshaller object from the JAXBContext, which will handle the actual serialization
        Marshaller marshaller = context.createMarshaller();

        // Set a property to format the output XML (to make it more human-readable)
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // Marshal the Person object into an XML file at the specified file path
        marshaller.marshal(person, new File(filePath));
    }
}