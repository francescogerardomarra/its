package com.example.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

/**
 * User entity representing a user in the shop system.
 */
@Getter // Lombok annotation to generate getter methods
@Setter // Lombok annotation to generate setter methods
@NoArgsConstructor // Lombok annotation to generate a no-args constructor
@Entity // Marks this class as a JPA entity
@Table(name = "User", schema = "shop_schema") // Maps this entity to the "User" table in "shop_schema"
public class User {

    /**
     * Primary key, automatically generated.
     */
    @Id // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Specifies auto-incrementing primary key generation
    @Column(name = "user_id")
    private Integer userId;

    /**
     * Unique username for the user.
     */
    @Column(name = "username", nullable = false, unique = true, length = 50)
    // Ensures this column is non-null and unique
    private String username;

    /**
     * Unique email for the user.
     */
    @Column(name = "email", nullable = false, unique = true, length = 100) // Ensures this column is non-null and unique
    private String email;

    /**
     * Timestamp of user creation.
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    // Prevents updates and ensures non-null constraint
    private LocalDateTime createdAt = LocalDateTime.now();

    /**
     * One user can have many orders.
     * The `mappedBy = "user"` indicates that the `Order` entity owns the relationship,
     * with the `user` field in the `Order` entity holding the foreign key reference to `User`.
     */
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Order> orders;
}
