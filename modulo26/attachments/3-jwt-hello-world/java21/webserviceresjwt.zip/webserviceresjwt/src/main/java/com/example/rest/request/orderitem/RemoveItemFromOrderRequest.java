package com.example.rest.request.orderitem;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * Request class for deleting an Item from an Order.
 * Used when sending a DELETE request to remove an Item from an Order.
 */
@Getter
@Setter
public class RemoveItemFromOrderRequest {

    @NotNull(message = "Order ID cannot be null")
    @JsonProperty("order_id")
    private Integer orderId;

    @NotNull(message = "Item ID cannot be null")
    @JsonProperty("item_id")
    private Integer itemId;
}
