package com.example;  // Specifies the package in which this class belongs

public class Main {  // Declares the Main class, which contains the main method
    public static void main(String[] args) {  // Main method where the program execution starts

        // Define the path to the JSON schema file
        String schemaPath = "src/main/resources/person_schema.json";

        // List of JSON files to be validated and deserialized
        String[] jsonFiles = {
                "src/main/resources/valid_person.json",  // A valid JSON file
                "src/main/resources/invalid_person1.json",  // An invalid JSON file (1)
                "src/main/resources/invalid_person2.json",  // An invalid JSON file (2)
                "src/main/resources/invalid_person3.json"  // An invalid JSON file (3)
        };

        // Iterate over each JSON file for validation and deserialization
        for (String jsonFile : jsonFiles) {
            try {
                // Call the validateAndDeserialize method from JsonHandler
                Person person = JsonHandler.validateAndDeserialize(jsonFile, schemaPath);

                // If successful, this message is printed, showing person details and file path
                System.out.println("SUCCESS - Deserialized Person from " + jsonFile + ": ");
                System.out.println("Name: " + person.getName() + ", Age: " + person.getAge() + ", Email: " + person.getEmail());

            } catch (Exception e) {  // If an error occurs during validation or deserialization
                // Print an error message indicating failure, including the file name and the error message
                System.out.println("FAILURE - Validation failed for " + jsonFile + ": " + e.getMessage());
            }
        }
    }
}