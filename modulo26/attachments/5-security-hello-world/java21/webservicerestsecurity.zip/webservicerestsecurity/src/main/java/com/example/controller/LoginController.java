package com.example.controller;

import com.example.security.jwt.AdminTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller responsible for handling login requests.
 * This controller supports Basic Authentication to authenticate users and then generates a JWT token for further requests.
 *
 * Flow:
 * 1. The user hits the /shop/login endpoint with Basic Authentication credentials (username and password).
 * 2. If authentication is successful, the system generates a JWT token using the AdminTokenProvider.
 * 3. The generated JWT token is returned to the user with the "Bearer" prefix, which can be used for authenticated requests.
 */
@RestController
@RequestMapping("/shop/login")
public class LoginController {

    // AdminTokenProvider used for generating JWT tokens
    private final AdminTokenProvider tokenProvider;

    /**
     * Constructor-based dependency injection to provide the AdminTokenProvider.
     *
     * @param tokenProvider The AdminTokenProvider to generate JWT tokens.
     */
    @Autowired
    public LoginController(AdminTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    /**
     * Login endpoint to authenticate the user via Basic Authentication.
     * Once authenticated, this method will generate a JWT token and return it to the client.
     *
     * @return ResponseEntity containing the JWT token as a Bearer token.
     *         The token can then be used for subsequent authenticated requests.
     */
    @PostMapping
    public ResponseEntity<?> login() {
        // Generate the JWT token using the AdminTokenProvider
        // The AdminTokenProvider encapsulates the logic of creating a secure JWT token for the admin.
        String token = tokenProvider.generateToken();

        // Return the generated JWT token to the client as a Bearer token.
        // The "Bearer " prefix indicates that this token is for authentication purposes.
        return ResponseEntity.ok().body("Bearer " + token);
    }
}
