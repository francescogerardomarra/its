package com.example.controller;

import com.example.model.Item;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.model.key.OrderItemKey;
import com.example.rest.request.orderitem.AddItemToOrderRequest;
import com.example.rest.request.orderitem.RemoveItemFromOrderRequest;
import com.example.rest.response.orderitem.AddItemToOrderResponse;
import com.example.rest.response.orderitem.RemoveItemFromOrderResponse;
import com.example.service.ItemService;
import com.example.service.OrderItemService;
import com.example.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/shop/orderitems")  // Base path for order item-related endpoints
public class OrderItemController {

    private final OrderItemService orderItemService;
    private final OrderService orderService;
    private final ItemService itemService;

    @Autowired
    public OrderItemController(OrderItemService orderItemService, OrderService orderService, ItemService itemService) {
        this.orderItemService = orderItemService;
        this.orderService = orderService;
        this.itemService = itemService;
    }

    // Add an item to an order (Use POST for creating the relationship)
    @PostMapping  // Changed from PUT to POST
    public ResponseEntity<AddItemToOrderResponse> addItemToOrder(@RequestBody AddItemToOrderRequest request) {
        // Retrieve the Order and Item by their IDs
        Optional<Order> orderOptional = orderService.getOrderById(request.getOrderId());
        Optional<Item> itemOptional = itemService.getItemById(request.getItemId());

        // Check if the Order and Item exist
        if (orderOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(new AddItemToOrderResponse(
                    request.getOrderId(), request.getItemId(), request.getQuantity(), "Order not found."));
        }

        if (itemOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(new AddItemToOrderResponse(
                    request.getOrderId(), request.getItemId(), request.getQuantity(), "Item not found."));
        }

        Order order = orderOptional.get();
        Item item = itemOptional.get();

        // Create a composite key for the OrderItem
        OrderItemKey orderItemKey = new OrderItemKey(request.getOrderId(), request.getItemId());

        // Check if the OrderItem already exists
        Optional<OrderItem> existingOrderItem = orderItemService.getOrderItemById(orderItemKey);

        if (existingOrderItem.isPresent()) {
            // If the item already exists in the order, update the quantity
            OrderItem orderItem = existingOrderItem.get();
            orderItem.setQuantity(orderItem.getQuantity() + request.getQuantity());
            orderItemService.saveOrderItem(orderItem);
        } else {
            // If the item doesn't exist in the order, create a new OrderItem
            OrderItem newOrderItem = new OrderItem();
            newOrderItem.setId(orderItemKey);
            newOrderItem.setOrder(order);  // Use the retrieved order
            newOrderItem.setItem(item);    // Use the retrieved item
            newOrderItem.setQuantity(request.getQuantity());

            orderItemService.saveOrderItem(newOrderItem);
        }

        // Preparing the response
        AddItemToOrderResponse response = new AddItemToOrderResponse(
                request.getOrderId(),
                request.getItemId(),
                request.getQuantity(),
                "Item successfully added to the order."
        );

        return ResponseEntity.ok(response);
    }

    // Remove an item from an order
    @DeleteMapping  // Method-level mapping for DELETE
    public ResponseEntity<RemoveItemFromOrderResponse> removeItemFromOrder(@RequestBody RemoveItemFromOrderRequest request) {
        // Retrieve the Order and Item by their IDs
        Optional<Order> orderOptional = orderService.getOrderById(request.getOrderId());
        Optional<Item> itemOptional = itemService.getItemById(request.getItemId());

        // Check if the Order and Item exist
        if (orderOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(new RemoveItemFromOrderResponse(
                    request.getOrderId(), request.getItemId(), "Order not found."));
        }

        if (itemOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(new RemoveItemFromOrderResponse(
                    request.getOrderId(), request.getItemId(), "Item not found."));
        }

        OrderItemKey orderItemKey = new OrderItemKey(request.getOrderId(), request.getItemId());
        Optional<OrderItem> orderItemOptional = orderItemService.getOrderItemById(orderItemKey);

        if (orderItemOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(new RemoveItemFromOrderResponse(
                    request.getOrderId(), request.getItemId(), "Item not found in the order."));
        }

        // If the OrderItem exists, delete it
        orderItemService.deleteOrderItem(orderItemKey);

        // Preparing the response
        RemoveItemFromOrderResponse response = new RemoveItemFromOrderResponse(
                request.getOrderId(),
                request.getItemId(),
                "Item successfully removed from the order."
        );

        return ResponseEntity.ok(response);
    }
}
