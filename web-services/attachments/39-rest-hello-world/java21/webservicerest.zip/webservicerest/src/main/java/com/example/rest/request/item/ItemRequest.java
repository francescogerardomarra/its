package com.example.rest.request.item;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

/**
 * Request class for modifying an Item's details.
 * Used when sending a POST or PUT request to create or modify an Item.
 */
@Getter
@Setter
public class ItemRequest {

    @Nullable
    @JsonProperty("item_id")
    private Integer itemId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @Positive(message = "Price must be positive")
    @JsonProperty("price")
    private Double price;
}
