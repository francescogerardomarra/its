package com.example.repository;

import com.example.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository extends JpaRepository<Person, Long> {

    // By extending JpaRepository, the following methods are provided by default:

    // 1. save(S entity) - Saves a given entity, either inserting or updating it.
    // 2. saveAll(Iterable<S> entities) - Saves all given entities.
    // 3. findById(ID id) - Retrieves an entity by its id. Returns an Optional.
    // 4. existsById(ID id) - Checks whether an entity with the given id exists.
    // 5. findAll() - Retrieves all entities of type T.
    // 6. findAllById(Iterable<ID> ids) - Retrieves all entities with the given ids.
    // 7. count() - Returns the number of entities of type T.
    // 8. deleteById(ID id) - Deletes the entity with the given id.
    // 9. delete(T entity) - Deletes a given entity.
    // 10. deleteAllById(Iterable<? extends ID> ids) - Deletes all entities with the given ids.
    // 11. deleteAll(Iterable<? extends T> entities) - Deletes all given entities.
    // 12. deleteAll() - Deletes all entities of type T.

    // These methods are automatically implemented by Spring Data JPA, so no need to manually define them.
}
