package com.example.service;

import com.example.dto.user.UserDTO;
import com.example.model.User;
import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Save or update a User
    public UserDTO saveUser(UserDTO userDTO) {
        User user = new User();
        user.setUserId(userDTO.getUserId());
        user.setUsername(userDTO.getUsername());
        user.setEmail(userDTO.getEmail());
        User savedUser = userRepository.save(user);

        return new UserDTO(
                savedUser.getUserId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getCreatedAt().toString()
        );
    }

    // Retrieve a User by ID
    public Optional<UserDTO> getUserById(Integer userId) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isEmpty()) {
            return Optional.empty();
        }

        User u = user.get();
        UserDTO userDTO = new UserDTO(u.getUserId(), u.getUsername(), u.getEmail(), u.getCreatedAt().toString());
        return Optional.of(userDTO);
    }

    // Retrieve a User by Username
    public Optional<UserDTO> getUserByUsername(String username) {
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isEmpty()) {
            return Optional.empty();
        }

        User u = user.get();
        UserDTO userDTO = new UserDTO(u.getUserId(), u.getUsername(), u.getEmail(), u.getCreatedAt().toString());
        return Optional.of(userDTO);
    }

    // Retrieve a User by Email
    public Optional<UserDTO> getUserByEmail(String email) {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isEmpty()) {
            return Optional.empty();
        }

        User u = user.get();
        UserDTO userDTO = new UserDTO(u.getUserId(), u.getUsername(), u.getEmail(), u.getCreatedAt().toString());
        return Optional.of(userDTO);
    }

    // Delete a User by ID
    public void deleteUser(Integer userId) {
        userRepository.deleteById(userId);
    }
}
