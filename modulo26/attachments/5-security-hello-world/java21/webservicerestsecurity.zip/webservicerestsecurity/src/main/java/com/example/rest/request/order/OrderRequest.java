package com.example.rest.request.order;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * Request class for creating an Order.
 * Used when sending a POST request to create a new Order.
 */
@Getter
@Setter
public class OrderRequest {

    @NotNull(message = "User ID cannot be null")
    @JsonProperty("user_id")
    private Integer userId;
}
