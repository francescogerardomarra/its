package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;  // Jackson library to handle JSON deserialization
import org.everit.json.schema.Schema;  // Everit library for JSON schema validation
import org.everit.json.schema.loader.SchemaLoader;  // Everit library for loading the JSON schema
import org.json.JSONObject;  // JSON object representation used for schema and data
import org.json.JSONTokener;  // JSON tokener for reading and parsing JSON
import jakarta.validation.*;  // Jakarta Bean Validation API for validating Java beans

import java.io.FileInputStream;  // File stream to read JSON and schema files
import java.io.IOException;  // Exception handling
import java.util.Set;  // Set collection for constraint violations

public class JsonHandler {

    // This method handles both JSON schema validation and Java Bean Validation (JSR 303/JSR 380) for the Person object.
    public static Person validateAndDeserialize(String jsonFilePath, String schemaFilePath) throws IOException {
        // Open the JSON schema file and JSON data file using FileInputStream
        try (FileInputStream schemaStream = new FileInputStream(schemaFilePath);
             FileInputStream jsonStream = new FileInputStream(jsonFilePath)) {

            // Load the JSON schema from the schema file using Everit SchemaLoader
            JSONObject rawSchema = new JSONObject(new JSONTokener(schemaStream));  // Read schema file
            Schema schema = SchemaLoader.load(rawSchema);  // Load the schema using the loader
            JSONObject jsonData = new JSONObject(new JSONTokener(jsonStream));  // Read JSON data

            // Validate the JSON data against the loaded schema
            try {
                schema.validate(jsonData);  // Throws an exception if the JSON doesn't match the schema
            } catch (Exception e) {
                // If JSON schema validation fails, output the failure reason
                System.out.println("JSON Schema Validation failed: " + e.getMessage());
                throw new RuntimeException("JSON Schema Validation failed", e);  // Re-throw to stop further processing
            }

            // Use Jackson ObjectMapper to deserialize JSON data into the Person object
            ObjectMapper objectMapper = new ObjectMapper();  // Create an ObjectMapper instance
            Person person = objectMapper.readValue(jsonData.toString(), Person.class);  // Deserialize JSON to Person object

            // Manually trigger Bean Validation for the Person object
            try {
                validatePerson(person);  // Trigger Bean Validation, this is where the annotations will be checked
            } catch (RuntimeException e) {
                // If Java Bean Validation fails, output the failure reason
                System.out.println("Java Bean Validation failed: " + e.getMessage());
                throw e;  // Re-throw the exception to propagate the error
            }

            // Return the deserialized Person object if it is valid
            return person;  // Return the successfully validated and deserialized Person object
        }
    }

    // This method performs manual validation of the Person object using Jakarta Bean Validation (JSR 303/JSR 380)
    private static void validatePerson(Person person) {
        // Create a ValidatorFactory and Validator instance to perform the validation
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();  // Build the default ValidatorFactory
        Validator validator = factory.getValidator();  // Obtain a Validator instance from the factory

        // Perform the actual validation of the Person object
        Set<ConstraintViolation<Person>> violations = validator.validate(person);  // Validate the Person object and collect violations

        // If there are any validation violations, handle them by throwing an exception
        if (!violations.isEmpty()) {  // If there are any validation issues
            StringBuilder errorMessage = new StringBuilder("Java Bean Validation failed:");  // Initialize an error message
            for (ConstraintViolation<Person> violation : violations) {  // Loop through each violation
                errorMessage.append("\n").append(violation.getMessage());  // Append the violation message to the error message
            }
            // Throw a RuntimeException with the full list of validation error messages
            throw new RuntimeException(errorMessage.toString());  // Exception is thrown if validation fails
        }
    }
}