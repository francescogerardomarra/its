package com.example;

import jakarta.xml.bind.*;  // Import JAXB classes for marshalling and unmarshalling
import javax.xml.validation.Schema;  // Import Schema for XML validation
import javax.xml.validation.SchemaFactory;  // Import SchemaFactory to create Schema objects
import javax.xml.XMLConstants;  // Import XMLConstants for schema constants
import java.io.File;  // Import File class for file handling

public class XMLHandler {

    // Method to deserialize XML without validation
    public static Person deserializeWithoutValidation(String filePath) throws JAXBException {
        // Create a JAXB context for the Person class, which tells JAXB how to process the XML
        JAXBContext context = JAXBContext.newInstance(Person.class);

        // Create an unmarshaller object which will be used to convert the XML back to a Java object
        Unmarshaller unmarshaller = context.createUnmarshaller();

        // Unmarshal the XML file at the given filePath and cast the result to a Person object
        return (Person) unmarshaller.unmarshal(new File(filePath));
    }

    // Method to deserialize XML with validation using a given schema
    public static Person deserializeWithValidation(String filePath, String schemaPath) throws Exception {
        // Create a JAXB context for the Person class to handle the XML binding
        JAXBContext context = JAXBContext.newInstance(Person.class);

        // Create an unmarshaller object which will be used to convert XML into a Java object
        Unmarshaller unmarshaller = context.createUnmarshaller();

        // Create a SchemaFactory object to parse and create a Schema object for XML validation
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

        // Create a Schema object using the schema file provided by the schemaPath
        Schema schema = sf.newSchema(new File(schemaPath));

        // Set the schema for the unmarshaller to enforce XML validation
        unmarshaller.setSchema(schema);

        // Unmarshal the XML file at the given filePath, validate it against the schema,
        // and return the resulting Person object
        return (Person) unmarshaller.unmarshal(new File(filePath));
    }
}