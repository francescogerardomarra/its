// Hello.java
public class Hello {
    public static void main(String[] args) throws InterruptedException {
    	while(true){
    		System.out.println("Hello, World from Java!");
    		Thread.sleep(10000);
    	}
    }
}
