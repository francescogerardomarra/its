package com.example.repository;

import com.example.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * The `OrderRepository` interface provides basic CRUD operations for the `Order` entity.
 * By extending `JpaRepository`, it inherits several methods for working with the `Order` entity, including:
 * <ul>
 *     <li>`save(S entity)` - Saves or updates an `Order` entity in the database.</li>
 *     <li>`findById(ID id)` - Finds an `Order` entity by its primary key (`orderId`).</li>
 *     <li>`findAll()` - Retrieves a list of all `Order` entities.</li>
 *     <li>`deleteById(ID id)` - Deletes an `Order` entity by its primary key (`orderId`).</li>
 *     <li>`delete(S entity)` - Deletes a specific `Order` entity.</li>
 * </ul>
 *
 * <p>
 * The method `findByUser_UserId` demonstrates how Spring Data JPA generates queries automatically
 * by interpreting method names based on naming conventions.
 * Spring Data JPA translates method names into SQL or JPQL queries at runtime.
 * </p>
 *
 * <h3>Method Name Conventions:</h3>
 * Spring Data JPA uses method name conventions to generate queries dynamically. The naming conventions follow these rules:
 * <ul>
 *     <li>`findBy` - This prefix indicates that the method will retrieve data.</li>
 *     <li>The next part of the method name specifies the field or property that the query will filter by.</li>
 *     <li>If you have a relationship between entities (e.g., `Order` and `User`), you can traverse the relationships by including the related entity's property in the method name.</li>
 *     <li>For example, `User` refers to the `User` entity, and `UserId` refers to the `userId` property in the `User` entity, which is mapped as a foreign key in the `Order` entity via the `user` field.</li>
 * </ul>
 *
 * <h3>Query Generation:</h3>
 * Spring Data JPA will automatically generate a query like:
 * <pre>
 *     SELECT o FROM Order o WHERE o.user.userId = ?1
 * </pre>
 * This query selects `Order` entities where the `userId` of the associated `User` matches the provided `userId`.
 *
 * <h3>Return Type:</h3>
 * Since the method returns a `List<Order>`, it will return an empty list if no matching orders are found for the given `userId`.
 * <br>
 * There's no need to wrap the result in `Optional` for a `List`, as `List` can always be returned, even if it's empty.
 * </p>
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {

    /**
     * Retrieves a list of `Order` entities associated with a specific `userId`.
     * Spring Data JPA automatically implements this method based on the name, generating a query
     * like: `SELECT o FROM Order o WHERE o.user.userId = ?1`
     *
     * @param userId The `userId` of the `User` whose orders are being queried.
     * @return A list of `Order` entities related to the given `userId`.
     *         Returns an empty list if no orders are found.
     */
    List<Order> findByUser_UserId(Integer userId);
}
