package com.example.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Starting with Spring Boot 3.x and Java 21, JPA annotations now use the 'jakarta.persistence' package instead of 'javax.persistence'.
// This is due to the migration from Java EE to Jakarta EE, which occurred after Java 17. The 'jakarta' namespace is now the standard for JPA and other Java EE technologies.
import jakarta.persistence.*;

/**
 * This class represents a Person entity in the context of Object-Relational Mapping (ORM) with JPA.
 * It is used for mapping Java objects (entities) to database tables, and allows for CRUD operations on the "person" table.
 *
 * This class is not related to SOAP web services but is used for managing database records using Spring Data JPA.
 * The 'jakarta.persistence' annotations are used for ORM mapping to interact with a relational database.
 */
@Entity // Marks the class as an entity that will be mapped to a database table
@Table(name = "person", schema = "my_schema") // Specifies the name of the table in the database and the schema it belongs to
@Getter // Lombok annotation that automatically generates getters for all fields
@Setter // Lombok annotation that automatically generates setters for all fields
@NoArgsConstructor // Lombok annotation to create a no-argument constructor which is required by Hibernate
public class Person {

    @Id // Denotes the primary key of the entity
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Specifies how the primary key is generated (auto-increment)
    private Long id;

    private String name; // The name of the person
    private String surname; // The surname of the person
    private String city; // The city where the person lives
    private int age; // The age of the person
}
