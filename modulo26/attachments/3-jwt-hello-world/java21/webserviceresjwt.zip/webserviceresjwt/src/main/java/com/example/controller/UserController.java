package com.example.controller;

import com.example.dto.user.UserDTO;
import com.example.rest.request.user.RemoveUserRequest;
import com.example.rest.request.user.UserRequest;
import com.example.rest.response.user.UserResponse;
import com.example.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/shop/users")  // Base path for user-related operations
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Create a new user
    @PostMapping
    public ResponseEntity<UserResponse> createUser(@RequestBody @Valid UserRequest userRequest) {
        UserDTO userDTO = new UserDTO(null, userRequest.getUsername(), userRequest.getEmail(), null);
        UserDTO savedUser = userService.saveUser(userDTO);

        UserResponse response = new UserResponse(
                savedUser.getUserId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getCreatedAt()
        );

        return ResponseEntity.ok(response);
    }

    // Modify an existing user (update username and/or email)
    @PutMapping
    public ResponseEntity<UserResponse> updateUser(@RequestBody @Valid UserRequest userRequest) {
        Optional<UserDTO> existingUser = userService.getUserByEmail(userRequest.getEmail());
        if (existingUser.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserDTO userDTO = existingUser.get();
        userDTO.setUsername(userRequest.getUsername());
        userDTO.setEmail(userRequest.getEmail());

        UserDTO updatedUser = userService.saveUser(userDTO);

        UserResponse response = new UserResponse(
                updatedUser.getUserId(),
                updatedUser.getUsername(),
                updatedUser.getEmail(),
                updatedUser.getCreatedAt()
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve user by ID (query parameter)
    @GetMapping(params = "id")
    public ResponseEntity<UserResponse> getUserById(@RequestParam Integer id) {
        Optional<UserDTO> user = userService.getUserById(id);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt()
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve user by email (query parameter)
    @GetMapping(params = "email")
    public ResponseEntity<UserResponse> getUserByEmail(@RequestParam String email) {
        Optional<UserDTO> user = userService.getUserByEmail(email);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt()
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve user by username (query parameter)
    @GetMapping(params = "username")
    public ResponseEntity<UserResponse> getUserByUsername(@RequestParam String username) {
        Optional<UserDTO> user = userService.getUserByUsername(username);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt()
        );

        return ResponseEntity.ok(response);
    }

    // Remove a user (delete)
    @DeleteMapping
    public ResponseEntity<String> deleteUser(@RequestBody @Valid RemoveUserRequest request) {
        Optional<UserDTO> user = userService.getUserById(request.getUserId());
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        userService.deleteUser(request.getUserId());

        return ResponseEntity.ok("User deleted successfully");
    }
}
