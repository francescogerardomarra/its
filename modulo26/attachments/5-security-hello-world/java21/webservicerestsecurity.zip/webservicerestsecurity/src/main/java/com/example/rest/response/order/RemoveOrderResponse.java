package com.example.rest.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Response class for removing an Order.
 * This response will confirm that an Order has been successfully removed from the system.
 */
@Getter
@Setter
@AllArgsConstructor
public class RemoveOrderResponse {

    @JsonProperty("order_id")
    private Integer orderId;

    @JsonProperty("message")
    private String message;
}
