package com.example.rest.response.orderitem;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Response class for deleting an Item from an Order.
 * This response will confirm that an item has been successfully removed from the order.
 */
@Getter
@Setter
@AllArgsConstructor
public class RemoveItemFromOrderResponse {

    @JsonProperty("order_id")
    private Integer orderId;

    @JsonProperty("item_id")
    private Integer itemId;

    @JsonProperty("message")
    private String message;
}
