package com.example.service;

import com.example.dto.order.OrderDTO;
import com.example.dto.order.OrderStatusDTO;
import com.example.dto.orderitem.OrderItemDTO;
import com.example.model.Order;
import com.example.model.User;
import com.example.model.enums.OrderStatus;
import com.example.repository.OrderRepository;
import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository; // Add UserRepository to fetch User by ID

    @Autowired
    public OrderService(OrderRepository orderRepository, UserRepository userRepository) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
    }

    // Save an Order using OrderDTO
    public Optional<OrderDTO> saveOrder(OrderDTO orderDTO) {
        // Fetch the User entity based on the userId in the DTO
        User user = userRepository.findById(orderDTO.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create the Order entity and set properties
        Order order = new Order();
        order.setUser(user);

        Order savedOrder = orderRepository.save(order);

        // Return saved order as OrderDTO
        return Optional.of(new OrderDTO(
                savedOrder.getOrderId(),
                savedOrder.getOrderDate(),
                savedOrder.getStatus().toString(), // Converting OrderStatus to String
                savedOrder.getUser().getUserId(),
                Optional.ofNullable(savedOrder.getOrderItems())  // Optional to avoid NPE
                        .orElse(Collections.emptyList())         // Default to an empty list if null
                        .stream()
                        .map(item -> new OrderItemDTO(item.getOrder().getOrderId(), item.getItem().getItemId(), item.getQuantity()))
                        .collect(Collectors.toList())
        ));
    }

    // Retrieve an Order by ID
    public Optional<OrderDTO> getOrderById(Integer orderId) {
        Optional<Order> order = orderRepository.findById(orderId);
        if (order.isEmpty()) {
            return Optional.empty();
        }

        OrderDTO orderDTO = new OrderDTO(
                order.get().getOrderId(),
                order.get().getOrderDate(),
                order.get().getStatus().toString(),
                order.get().getUser().getUserId(),
                order.get().getOrderItems().stream()
                        .map(item -> new OrderItemDTO(item.getOrder().getOrderId(), item.getItem().getItemId(), item.getQuantity()))
                        .collect(Collectors.toList())
        );

        return Optional.of(orderDTO);
    }

    // Retrieve Orders by User ID
    public List<OrderDTO> getOrdersByUserId(Integer userId) {
        List<Order> orders = orderRepository.findByUser_UserId(userId);
        return orders.stream()
                .map(order -> new OrderDTO(
                        order.getOrderId(),
                        order.getOrderDate(),
                        order.getStatus().toString(),
                        order.getUser().getUserId(),
                        order.getOrderItems().stream()
                                .map(item -> new OrderItemDTO(item.getOrder().getOrderId(), item.getItem().getItemId(), item.getQuantity()))
                                .collect(Collectors.toList())
                ))
                .collect(Collectors.toList());
    }

    /**
     * Retrieves a list of orders with a specific status.
     *
     * @param status The OrderStatus to filter by.
     * @return A list of OrderStatusDTO objects containing orderId and status.
     */
    public List<OrderStatusDTO> getOrdersByStatus(OrderStatus status) {
        List<Order> orders = orderRepository.findByStatus(status);
        return orders.stream()
                .map(order -> new OrderStatusDTO(order.getOrderId(), order.getStatus()))
                .collect(Collectors.toList());
    }

    // Delete an Order by ID
    public void deleteOrder(Integer orderId) {
        orderRepository.deleteById(orderId);
    }
}
