package com.example.controller;

import com.example.dto.order.OrderDTO;
import com.example.rest.request.order.OrderRequest;
import com.example.rest.request.order.RemoveOrderRequest;
import com.example.rest.response.RemoveOrderResponse;
import com.example.rest.response.order.OrderResponse;
import com.example.service.OrderService;
import com.example.service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/shop/orders")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;
    private final UserService userService;

    @Autowired
    public OrderController(OrderService orderService, UserService userService) {
        this.orderService = orderService;
        this.userService = userService;
    }

    // Create a new order (without items initially)
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@RequestBody @Valid OrderRequest orderRequest) {
        logger.info("Received request to create a new order for userId: {}", orderRequest.getUserId());

        // Pass the DTO to the service
        OrderDTO orderDTO = new OrderDTO(
                null, // orderId is not set for new orders
                null, // orderDate is set in the service layer
                null, // status is set in the service layer
                orderRequest.getUserId(), // The userId from the request
                null // No items in the order initially
        );

        Optional<OrderDTO> savedOrder = orderService.saveOrder(orderDTO);

        // Check if the order was saved and return appropriate response
        if (savedOrder.isEmpty()) {
            logger.warn("Failed to save the order for userId: {}", orderRequest.getUserId());
            return ResponseEntity.badRequest().build();
        }

        OrderDTO savedOrderDTO = savedOrder.get();
        OrderResponse response = new OrderResponse(
                savedOrderDTO.getOrderId(),
                savedOrderDTO.getOrderDate(),
                savedOrderDTO.getStatus(),
                savedOrderDTO.getUserId(),
                savedOrderDTO.getOrderItems()
        );

        logger.info("Successfully created order with orderId: {}", savedOrderDTO.getOrderId());
        return ResponseEntity.status(201).body(response);
    }

    // Retrieve an order by its ID with explicit parameter
    @GetMapping(params = "orderId")
    public ResponseEntity<OrderResponse> getOrderById(@RequestParam Integer orderId) {
        logger.info("Received request to retrieve order with orderId: {}", orderId);

        Optional<OrderDTO> orderDTO = orderService.getOrderById(orderId);

        if (orderDTO.isEmpty()) {
            logger.warn("Order with orderId: {} not found", orderId);
            return ResponseEntity.notFound().build();
        }

        OrderDTO orderDTOResponse = orderDTO.get();
        OrderResponse response = new OrderResponse(
                orderDTOResponse.getOrderId(),
                orderDTOResponse.getOrderDate(),
                orderDTOResponse.getStatus(),
                orderDTOResponse.getUserId(),
                orderDTOResponse.getOrderItems()
        );

        logger.info("Successfully retrieved order with orderId: {}", orderDTOResponse.getOrderId());
        return ResponseEntity.ok(response);
    }

    // Retrieve orders by user ID
    @GetMapping(params = "userId")
    public ResponseEntity<List<OrderResponse>> getOrdersByUserId(@RequestParam Integer userId) {
        logger.info("Received request to retrieve orders for userId: {}", userId);

        List<OrderDTO> ordersDTO = orderService.getOrdersByUserId(userId);

        if (ordersDTO.isEmpty()) {
            logger.warn("No orders found for userId: {}", userId);
            return ResponseEntity.notFound().build();
        }

        List<OrderResponse> responses = ordersDTO.stream()
                .map(orderDTO -> new OrderResponse(
                        orderDTO.getOrderId(),
                        orderDTO.getOrderDate(),
                        orderDTO.getStatus(),
                        orderDTO.getUserId(),
                        orderDTO.getOrderItems()
                ))
                .collect(Collectors.toList());

        logger.info("Successfully retrieved {} orders for userId: {}", responses.size(), userId);
        return ResponseEntity.ok(responses);
    }

    // Delete an order by its ID
    @DeleteMapping
    public ResponseEntity<RemoveOrderResponse> deleteOrder(@RequestBody @Valid RemoveOrderRequest request) {
        logger.info("Received request to delete order with orderId: {}", request.getOrderId());

        Optional<OrderDTO> orderDTO = orderService.getOrderById(request.getOrderId());

        if (orderDTO.isEmpty()) {
            logger.warn("Order with orderId: {} not found", request.getOrderId());
            return ResponseEntity.notFound().build();
        }

        orderService.deleteOrder(request.getOrderId());

        RemoveOrderResponse response = new RemoveOrderResponse(
                request.getOrderId(),
                "Order deleted successfully"
        );

        logger.info("Successfully deleted order with orderId: {}", request.getOrderId());
        return ResponseEntity.ok(response);
    }
}
