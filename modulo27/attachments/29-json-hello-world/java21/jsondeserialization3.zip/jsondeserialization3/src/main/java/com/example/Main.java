package com.example;  // Specifies the package in which this class belongs

public class Main {  // Declares the Main class, which contains the main method
    public static void main(String[] args) {  // Main method where the program execution starts

        // Define the path to the JSON schema file
        String schemaPath = "src/main/resources/person_schema.json";

        // List of JSON files to be validated and deserialized
        String[] jsonFiles = {
                "src/main/resources/valid_person.json",       // ✅ Valid JSON
                "src/main/resources/invalid_person1.json",    // ❌ Name too short
                "src/main/resources/invalid_person2.json",    // ❌ Age too low
                "src/main/resources/invalid_person3.json"    // ❌ Invalid email format
        };

        // Iterate over each JSON file for validation and deserialization
        for (String jsonFile : jsonFiles) {
            System.out.println("\n** ATTEMPT TO DESERIALISE JSON FROM PATH " + jsonFile + " **");

            try {
                // Call the validateAndDeserialize method from JsonHandler
                Person person = JsonHandler.validateAndDeserialize(jsonFile, schemaPath);

                // If successful, print success message with person details
                System.out.println("SUCCESS - Deserialized Person from " + jsonFile + ": ");
                System.out.println("Name: " + person.getName() + ", Age: " + person.getAge() + ", Email: " + person.getEmail());

            } catch (Exception e) {  // Catch validation or deserialization errors
                // Print an error message indicating failure, including file name and error details
                System.out.println("FAILURE - Validation failed for " + jsonFile + ": " + e.getMessage());
            }
        }
    }
}