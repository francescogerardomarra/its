package com.example.dto.order;

import com.example.model.enums.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class OrderStatusDTO {
    private Integer orderId;
    private OrderStatus status;

}
