package com.example.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Item entity representing a product in the shop system.
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Item", schema = "shop_schema")
public class Item {

    /**
     * Primary key, automatically generated.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Integer itemId;

    /**
     * Name of the item.
     */
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    /**
     * Description of the item.
     */
    @Column(name = "description")
    private String description;

    /**
     * Price of the item, must be greater than zero.
     */
    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    /**
     * Available stock quantity, must be non-negative.
     */
    @Column(name = "stock_quantity", nullable = false)
    private Integer stockQuantity;

    /**
     * Many-to-Many relationship with Order through OrderItem.
     * An item can be part of multiple orders, and an order can contain multiple items.
     * The join table "OrderItem" maintains this relationship.
     */
    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
    private List<OrderItem> orderItems;
}
