package com.example;

import jakarta.xml.bind.JAXBContext;  // Import JAXBContext for creating JAXB context for binding
import jakarta.xml.bind.JAXBException;  // Import JAXBException for handling errors during marshalling/unmarshalling
import jakarta.xml.bind.Unmarshaller;  // Import Unmarshaller to convert XML back to Java objects
import java.io.File;  // Import File class to handle file input/output operations

public class XMLHandler {

    // This method deserializes (converts) an XML file into a Person object
    // It takes the file path of the XML file as a parameter
    public static Person deserializeFromXML(String filePath) throws JAXBException {

        // Create a JAXBContext instance for the Person class
        // JAXBContext is responsible for managing the XML binding process
        JAXBContext context = JAXBContext.newInstance(Person.class);

        // Create an Unmarshaller object using the JAXBContext
        // The Unmarshaller is responsible for converting XML data back into Java objects
        Unmarshaller unmarshaller = context.createUnmarshaller();

        // Unmarshal the XML file into a Person object and return it
        // The unmarshal method converts the XML data from the given file into a Java object
        return (Person) unmarshaller.unmarshal(new File(filePath));
    }
}