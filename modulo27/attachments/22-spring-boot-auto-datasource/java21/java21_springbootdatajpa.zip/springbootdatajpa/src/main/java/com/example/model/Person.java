package com.example.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Starting with Spring Boot 3.x and Java 21, JPA annotations now use the 'jakarta.persistence' package instead of 'javax.persistence'.
// This is due to the migration from Java EE to Jakarta EE, which occurred after Java 17. The 'jakarta' namespace is now the standard for JPA and other Java EE technologies.
import jakarta.persistence.*;

@Entity // This annotation is needed because we are using Spring Data JPA
@Table(name = "person", schema = "my_schema")
@Getter
@Setter
@NoArgsConstructor // Hibernate requires a no-argument constructor
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String surname;
    private String city;
    private int age;
}
