package com.example.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

/**
 * Item entity representing a product in the shop system.
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Item", schema = "shop_schema")
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Integer itemId;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "price", nullable = false)
    private Double price;

    @ManyToMany(mappedBy = "items") // Reference back from Order
    private Set<Order> orders;

}
