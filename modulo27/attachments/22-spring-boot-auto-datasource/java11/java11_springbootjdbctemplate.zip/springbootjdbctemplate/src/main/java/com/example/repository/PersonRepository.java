package com.example.repository;

import com.example.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PersonRepository {
    private final JdbcTemplate jdbcTemplate;

    @Autowired // Explicitly declare constructor injection
    public PersonRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void insertPerson(Person person) {
        String sql = "INSERT INTO my_schema.person (name, surname, city, age) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql, person.getName(), person.getSurname(), person.getCity(), person.getAge());
    }
}