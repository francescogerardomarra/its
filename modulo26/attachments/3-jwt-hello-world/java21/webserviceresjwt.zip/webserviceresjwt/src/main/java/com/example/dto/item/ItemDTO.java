package com.example.dto.item;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * DTO class for transferring Item data without exposing the internal entity relationships.
 */
@Getter
@Setter
@AllArgsConstructor
public class ItemDTO {

    private Integer itemId;
    private String name;
    private String description;
    private Double price;
    private Integer stockQuantity;
}
