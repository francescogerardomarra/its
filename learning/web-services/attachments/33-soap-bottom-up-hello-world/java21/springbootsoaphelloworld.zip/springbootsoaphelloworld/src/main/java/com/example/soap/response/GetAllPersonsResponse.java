package com.example.soap.response;  // The package declaration, organizing the class in a specific namespace within the project

// Importing necessary classes for JAXB annotations, which help convert between XML and Java objects
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

// Importing Lombok annotations to generate getter and setter methods automatically
import lombok.Getter;
import lombok.Setter;

// Importing List from Java’s utility library to represent a list of objects
import java.util.List;

/**
 * This class is used for serializing (converting to XML) the SOAP XML response message
 * that contains a list of persons. It will be used in the SOAP response, which
 * will be converted to XML by JAXB annotations.
 */
@XmlRootElement(name = "GetAllPersonsResponse", namespace = "http://example.com/soap")
// The @XmlRootElement annotation specifies that this class represents the root element of the XML
// response message. The 'name' defines the name of the root element in XML (GetAllPersonsResponse).
// The 'namespace' ensures that the SOAP response is correctly mapped with the specified namespace URI.
@XmlAccessorType(XmlAccessType.FIELD)
// @XmlAccessorType(XmlAccessType.FIELD) means that JAXB will access the fields directly (not getters/setters)
// when mapping XML to Java objects. This approach is often used for simplicity in XML binding.
@Getter  // Lombok annotation to automatically generate getter methods for the fields in this class
@Setter  // Lombok annotation to automatically generate setter methods for the fields in this class
public class GetAllPersonsResponse {

    /**
     * A list of InsertPersonResponse objects that will be included in the SOAP response.
     * Each InsertPersonResponse contains information about a person, such as their name,
     * which will be serialized to XML.
     */
    @XmlElement(required = true)
    // The @XmlElement annotation marks the 'persons' field to be included as an XML element in the SOAP response.
    // The 'required = true' indicates that this element must be present in the XML response.
    private List<InsertPersonResponse> persons;  // A list of InsertPersonResponse objects to be serialized into the XML response
}