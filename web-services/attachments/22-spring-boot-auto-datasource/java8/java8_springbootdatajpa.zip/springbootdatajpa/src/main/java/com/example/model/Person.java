package com.example.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity // This annotation is needed because we are using Spring Data JPA
@Table(name = "person", schema = "my_schema")
@Getter
@Setter
@NoArgsConstructor // Hibernate requires a no-argument constructor
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String surname;
    private String city;
    private int age;
}
