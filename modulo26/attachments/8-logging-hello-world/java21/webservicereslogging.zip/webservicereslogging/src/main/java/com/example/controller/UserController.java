package com.example.controller;

import com.example.dto.user.UserDTO;
import com.example.rest.request.user.RemoveUserRequest;
import com.example.rest.request.user.UserRequest;
import com.example.rest.response.user.UserResponse;
import com.example.service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/shop/users")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Create a new user
    @PostMapping
    public ResponseEntity<UserResponse> createUser(@RequestBody @Valid UserRequest userRequest) {
        logger.info("Received request to create user with username: {} and email: {}", userRequest.getUsername(), userRequest.getEmail());

        UserDTO userDTO = new UserDTO(null, userRequest.getUsername(), userRequest.getEmail(), null);
        UserDTO savedUser = userService.saveUser(userDTO);

        UserResponse response = new UserResponse(
                savedUser.getUserId(),
                savedUser.getUsername(),
                savedUser.getEmail(),
                savedUser.getCreatedAt()
        );

        logger.info("User created successfully with userId: {}", savedUser.getUserId());
        return ResponseEntity.ok(response);
    }

    // Modify an existing user (update username and/or email)
    @PutMapping
    public ResponseEntity<UserResponse> updateUser(@RequestBody @Valid UserRequest userRequest) {
        logger.info("Received request to update user with email: {}", userRequest.getEmail());

        Optional<UserDTO> existingUser = userService.getUserByEmail(userRequest.getEmail());
        if (existingUser.isEmpty()) {
            logger.warn("User with email: {} not found for update.", userRequest.getEmail());
            return ResponseEntity.notFound().build();
        }

        UserDTO userDTO = existingUser.get();
        userDTO.setUsername(userRequest.getUsername());
        userDTO.setEmail(userRequest.getEmail());

        UserDTO updatedUser = userService.saveUser(userDTO);

        UserResponse response = new UserResponse(
                updatedUser.getUserId(),
                updatedUser.getUsername(),
                updatedUser.getEmail(),
                updatedUser.getCreatedAt()
        );

        logger.info("User updated successfully with userId: {}", updatedUser.getUserId());
        return ResponseEntity.ok(response);
    }

    // Retrieve user by ID (query parameter)
    @GetMapping(params = "id")
    public ResponseEntity<UserResponse> getUserById(@RequestParam Integer id) {
        logger.info("Received request to retrieve user with id: {}", id);

        Optional<UserDTO> user = userService.getUserById(id);
        if (user.isEmpty()) {
            logger.warn("User with id: {} not found.", id);
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt()
        );

        logger.info("User retrieved successfully with userId: {}", user.get().getUserId());
        return ResponseEntity.ok(response);
    }

    // Retrieve user by email (query parameter)
    @GetMapping(params = "email")
    public ResponseEntity<UserResponse> getUserByEmail(@RequestParam String email) {
        logger.info("Received request to retrieve user with email: {}", email);

        Optional<UserDTO> user = userService.getUserByEmail(email);
        if (user.isEmpty()) {
            logger.warn("User with email: {} not found.", email);
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt()
        );

        logger.info("User retrieved successfully with userId: {}", user.get().getUserId());
        return ResponseEntity.ok(response);
    }

    // Retrieve user by username (query parameter)
    @GetMapping(params = "username")
    public ResponseEntity<UserResponse> getUserByUsername(@RequestParam String username) {
        logger.info("Received request to retrieve user with username: {}", username);

        Optional<UserDTO> user = userService.getUserByUsername(username);
        if (user.isEmpty()) {
            logger.warn("User with username: {} not found.", username);
            return ResponseEntity.notFound().build();
        }

        UserResponse response = new UserResponse(
                user.get().getUserId(),
                user.get().getUsername(),
                user.get().getEmail(),
                user.get().getCreatedAt()
        );

        logger.info("User retrieved successfully with userId: {}", user.get().getUserId());
        return ResponseEntity.ok(response);
    }

    // Remove a user (delete)
    @DeleteMapping
    public ResponseEntity<String> deleteUser(@RequestBody @Valid RemoveUserRequest request) {
        logger.info("Received request to delete user with userId: {}", request.getUserId());

        Optional<UserDTO> user = userService.getUserById(request.getUserId());
        if (user.isEmpty()) {
            logger.warn("User with userId: {} not found for deletion.", request.getUserId());
            return ResponseEntity.notFound().build();
        }

        userService.deleteUser(request.getUserId());
        logger.info("User with userId: {} deleted successfully.", request.getUserId());

        return ResponseEntity.ok("User deleted successfully");
    }
}
