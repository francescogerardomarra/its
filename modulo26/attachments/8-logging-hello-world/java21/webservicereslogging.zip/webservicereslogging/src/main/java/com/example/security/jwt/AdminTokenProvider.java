package com.example.security.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Date;

/**
 * This class is responsible for generating and validating JWT tokens for admin users.
 * It allows you to create a JWT token with claims such as subject, role, and permissions,
 * as well as validate and extract the claims from an incoming JWT token.
 */
@Component
public class AdminTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(AdminTokenProvider.class);

    @Value("${jwt.secret}")
    private String secretKeyString;

    @Value("${admin.jwt.claim.sub}")
    private String subject;

    @Value("${admin.jwt.claim.role}")
    private String role;

    @Value("${admin.jwt.claim.permission}")
    private String permissions;

    @Value("${admin.jwt.claim.expiration.ms}")
    private long expirationTime;

    /**
     * Generates a JWT token with claims and expiration.
     *
     * @return the JWT token string
     */
    public String generateToken() {
        Key secretKey = new SecretKeySpec(secretKeyString.getBytes(), SignatureAlgorithm.HS512.getJcaName());

        String token = Jwts.builder()
                .setSubject(subject)
                .claim("role", role)
                .claim("permissions", permissions)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(secretKey, SignatureAlgorithm.HS512)
                .compact();

        logger.debug("Generated JWT token for subject '{}': {}", subject, token);
        return token;
    }

    /**
     * Extracts claims from a JWT token.
     *
     * @param token the JWT token
     * @return the extracted claims
     */
    public Claims getClaims(String token) {
        Key secretKey = new SecretKeySpec(secretKeyString.getBytes(), SignatureAlgorithm.HS512.getJcaName());

        logger.debug("Parsing JWT token: {}", token);
        return Jwts.parserBuilder()
                .setSigningKey(secretKey)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    /**
     * Validates a JWT token.
     *
     * @param token the JWT token
     * @return true if valid, false otherwise
     */
    public boolean validateToken(String token) {
        try {
            Claims claims = getClaims(token);
            Date expirationDate = claims.getExpiration();

            if (expirationDate.before(new Date())) {
                logger.warn("JWT token has expired: {}", token);
                return false;
            }

            logger.debug("JWT token is valid for subject '{}'", claims.getSubject());
            return true;
        } catch (JwtException e) {
            logger.error("Invalid JWT token: {}", token, e);
            return false;
        }
    }
}
