package com.example.service;

import com.example.model.Order;
import com.example.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    // Create or update an Order
    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    // Retrieve all Orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // Retrieve an Order by ID
    public Optional<Order> getOrderById(Integer orderId) {
        return orderRepository.findById(orderId);
    }

    // Retrieve Orders by User ID
    public List<Order> getOrdersByUserId(Integer userId) {
        return orderRepository.findByUser_UserId(userId);
    }

    // Delete an Order by ID
    public void deleteOrder(Integer orderId) {
        orderRepository.deleteById(orderId);
    }
}
