package com.example.backend.controller;

import com.example.backend.dto.TextRequest;
import com.example.backend.service.TextService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/text")
public class TextController {

    private final TextService textService;

    @Autowired
    public TextController(TextService textService) {
        this.textService = textService;
    }

    @GetMapping
    public List<String> getText() {
        return textService.findAll();
    }

    @PostMapping
    public void saveText(@RequestBody TextRequest textRequest) {
        textService.save(textRequest.getText());
    }
}
