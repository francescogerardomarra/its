package com.example.service;

import com.example.model.Person;
import com.example.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonService {

    private final PersonRepository personRepository;

    @Autowired
    public PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    // Save or update a person
    public Person savePerson(Person person) {
        return personRepository.save(person); // Uses JpaRepository's save() method
    }

    // Retrieve all the persons
    public List<Person> getAllPersons() {
        return personRepository.findAll(); // Retrieves all persons from the database using JpaRepository
    }
}
