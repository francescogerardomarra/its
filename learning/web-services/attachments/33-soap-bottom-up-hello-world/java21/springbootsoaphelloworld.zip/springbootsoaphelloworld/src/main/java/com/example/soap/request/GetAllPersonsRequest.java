package com.example.soap.request;  // The package declaration, organizing this class within the project structure

// Importing the necessary JAXB annotation for XML binding
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * This class is used for deserializing the SOAP request to retrieve all persons.
 *
 * The class represents the SOAP request structure, and JAXB annotations are used
 * to map the SOAP XML request message to a Java object.
 *
 * This particular class does not contain any fields because the request
 * to retrieve all persons may not need any input data (it's simply asking for all the persons).
 * However, if needed, additional request fields could be added here in the future.
 */
@XmlRootElement(name = "GetAllPersonsRequest", namespace = "http://example.com/soap")
// The @XmlRootElement annotation marks this class as the root element in the SOAP request XML message.
// - 'name' defines the name of the root element in the SOAP request (GetAllPersonsRequest).
// - 'namespace' specifies the XML namespace to ensure the SOAP message is correctly identified and parsed.
public class GetAllPersonsRequest {
    // This class is kept simple, potentially empty, as it represents a request to fetch all persons
    // Additional details (e.g., filters, sorting parameters) could be added if the request needs them.
}
