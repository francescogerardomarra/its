package com.example;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Person {

    // @JsonProperty: This annotation is used to specify the name of the property during serialization and deserialization.
    // It maps the "full_name" JSON field to the "name" Java field.
    @JsonProperty("full_name")
    private String name;

    private int age;

    // @JsonIgnore: This annotation prevents the "password" field from being serialized or deserialized.
    // It tells Jackson to ignore this property during the JSON processing.
    @JsonIgnore
    private String password;

    // @JsonInclude: This annotation specifies that the field should only be included in serialization if its value is not null.
    // If the email field is null, it will be omitted from the JSON output.
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String email;

    // @JsonCreator: This annotation marks the constructor to be used for deserialization.
    // It allows the Jackson library to create a Person object using the provided properties during deserialization.
    @JsonCreator
    public Person(
            // @JsonProperty: Specifies that the constructor parameter "full_name" should be mapped from the "full_name" field in the JSON data.
            @JsonProperty("full_name") String name,
            @JsonProperty("age") int age) {
        this.name = name;
        this.age = age;
    }
}
