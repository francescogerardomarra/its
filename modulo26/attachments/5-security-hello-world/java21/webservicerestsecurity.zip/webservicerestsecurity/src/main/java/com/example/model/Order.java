package com.example.model;

import com.example.model.enums.OrderStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Order", schema = "shop_schema")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private Integer orderId;

    /**
     * Many orders can belong to one user.
     */
    @ManyToOne // Defines a many-to-one relationship with User
    @JoinColumn(name = "user_id_fk", nullable = false) // Specifies the foreign key column
    private User user;

    @Column(name = "order_date", nullable = false)
    private LocalDateTime orderDate = LocalDateTime.now();

    @Column(name = "status", nullable = false, length = 20)
    @Enumerated(EnumType.STRING) // Stores enum values as strings in the database
    private OrderStatus status = OrderStatus.pending;  // Default to pending

    /**
     * One order can have many order items.
     * The `mappedBy = "order"` indicates that the `OrderItem` entity owns the relationship,
     * with the `order` field in the `OrderItem` entity holding the foreign key reference to `Order`.
     */
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderItem> orderItems;
}
