package com.example.rest.request.orderitem;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

/**
 * Request class for adding an Item to an Order.
 * Used when sending a POST request to add an Item to an Order.
 */
@Getter
@Setter
public class AddItemToOrderRequest {

    @NotNull(message = "Order ID cannot be null")
    @JsonProperty("order_id")
    private Integer orderId;

    @NotNull(message = "Item ID cannot be null")
    @JsonProperty("item_id")
    private Integer itemId;

    @Positive(message = "Quantity must be greater than zero")
    @JsonProperty("quantity")
    private Integer quantity;
}
