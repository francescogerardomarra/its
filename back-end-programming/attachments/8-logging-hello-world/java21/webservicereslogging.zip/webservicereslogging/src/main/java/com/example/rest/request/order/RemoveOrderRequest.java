package com.example.rest.request.order;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * Request class for removing an Order.
 * Used when sending a DELETE request to remove an Order by its ID.
 */
@Getter
@Setter
public class RemoveOrderRequest {

    @NotNull(message = "Order ID cannot be null")
    @JsonProperty("order_id")
    private Integer orderId;
}
