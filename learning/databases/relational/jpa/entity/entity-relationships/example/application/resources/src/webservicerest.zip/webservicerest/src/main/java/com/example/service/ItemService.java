package com.example.service;

import com.example.model.Item;
import com.example.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    // Create or update an Item
    public Item saveItem(Item item) {
        return itemRepository.save(item);
    }

    // Retrieve all Items
    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    // Retrieve an Item by ID
    public Optional<Item> getItemById(Integer itemId) {
        return itemRepository.findById(itemId);
    }

    // Delete an Item by ID
    public void deleteItem(Integer itemId) {
        itemRepository.deleteById(itemId);
    }
}
