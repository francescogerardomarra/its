// This is the package declaration, indicating where this class resides in the project
package com.example.soap.request;

// Importing required annotations from Jakarta XML Binding (JAXB) to handle XML serialization and deserialization
import jakarta.xml.bind.annotation.XmlAccessType; // Defines the access level for the properties
import jakarta.xml.bind.annotation.XmlAccessorType; // Specifies how JAXB will access the fields
import jakarta.xml.bind.annotation.XmlElement; // Used to mark fields to be included in XML
import jakarta.xml.bind.annotation.XmlRootElement; // Marks the class as the root element in the XML
import lombok.Getter; // Lombok annotation to generate getter methods automatically
import lombok.Setter; // Lombok annotation to generate setter methods automatically

/**
 * This class is used for deserializing the SOAP XML request message.
 *
 * When a SOAP request is sent to the web service, it is formatted as an XML message.
 * This class serves as the Java object representation of that XML message,
 * and it will be used to bind (deserialize) the XML data into a Java object.
 * The annotations provided by JAXB allow for automatic conversion between
 * XML and Java objects, so the incoming SOAP message can be easily handled.
 *
 * In particular, this class represents the data structure of a "InsertPersonRequest"
 * in the SOAP message, which includes the person's name, surname, city, and age.
 */
@XmlRootElement(name = "InsertPersonRequest", namespace = "http://example.com/soap") // This annotation marks the class as the root element in the XML document; it also ensures the correct namespace for the SOAP request message.
@XmlAccessorType(XmlAccessType.FIELD) // This tells JAXB to use the fields for XML binding (instead of getter/setter methods)
@Getter // Lombok annotation to automatically generate getter methods for all fields
@Setter // Lombok annotation to automatically generate setter methods for all fields
public class InsertPersonRequest {

    // Field to store the person's name, annotated with @XmlElement to specify it's a part of the XML structure
    @XmlElement(required = true) // The "name" field is mandatory in the XML document
    private String name; // The person's name as a string

    // Field to store the person's surname, annotated with @XmlElement to specify it's a part of the XML structure
    @XmlElement(required = true) // The "surname" field is mandatory in the XML document
    private String surname; // The person's surname as a string

    // Field to store the person's city, annotated with @XmlElement to specify it's a part of the XML structure
    @XmlElement(required = true) // The "city" field is mandatory in the XML document
    private String city; // The city where the person lives, as a string

    // Field to store the person's age, annotated with @XmlElement to specify it's a part of the XML structure
    @XmlElement(required = true) // The "age" field is mandatory in the XML document
    private int age; // The person's age as an integer
}