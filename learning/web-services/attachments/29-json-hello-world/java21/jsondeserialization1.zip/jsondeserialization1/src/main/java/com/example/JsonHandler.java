package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;

public class JsonHandler {

    public static Person deserializeFromJson(String filePath) throws IOException {
        // Create ObjectMapper instance
        ObjectMapper objectMapper = new ObjectMapper();

        // Deserialize JSON file into Person object
        return objectMapper.readValue(new File(filePath), Person.class);
    }
}