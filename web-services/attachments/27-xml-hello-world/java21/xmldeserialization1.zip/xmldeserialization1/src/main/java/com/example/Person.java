package com.example;

import jakarta.xml.bind.annotation.XmlElement;  // Import JAXB annotation to map XML elements
import jakarta.xml.bind.annotation.XmlRootElement;  // Import JAXB annotation to mark this class as a root element in XML

// The @XmlRootElement annotation indicates that this class corresponds to the root element of an XML document
@XmlRootElement
public class Person {
    private String name;  // Field to store the name of the person
    private int age;  // Field to store the age of the person

    // Default constructor required by JAXB (Java Architecture for XML Binding)
    // JAXB requires a no-argument constructor for creating instances of this class during deserialization
    public Person() {}

    // Getter and setter methods for the 'name' field
    // The @XmlElement annotation tells JAXB to map the 'name' field to an XML element with the same name
    @XmlElement
    public String getName() {
        return name;  // Return the name of the person
    }
    public void setName(String name) {
        this.name = name;  // Set the name of the person
    }

    // Getter and setter methods for the 'age' field
    // The @XmlElement annotation tells JAXB to map the 'age' field to an XML element with the same name
    @XmlElement
    public int getAge() {
        return age;  // Return the age of the person
    }
    public void setAge(int age) {
        this.age = age;  // Set the age of the person
    }
}