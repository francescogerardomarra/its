package com.example.service;

import com.example.model.OrderItem;
import com.example.model.key.OrderItemKey;
import com.example.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderItemService {

    private final OrderItemRepository orderItemRepository;

    @Autowired
    public OrderItemService(OrderItemRepository orderItemRepository) {
        this.orderItemRepository = orderItemRepository;
    }

    // Create or update an OrderItem
    public OrderItem saveOrderItem(OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    // Retrieve all OrderItems
    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    // Retrieve an OrderItem by ID (using composite key)
    public Optional<OrderItem> getOrderItemById(OrderItemKey orderItemKey) {
        return orderItemRepository.findById(orderItemKey);
    }

    // Delete an OrderItem by ID (using composite key)
    public void deleteOrderItem(OrderItemKey orderItemKey) {
        orderItemRepository.deleteById(orderItemKey);
    }
}
