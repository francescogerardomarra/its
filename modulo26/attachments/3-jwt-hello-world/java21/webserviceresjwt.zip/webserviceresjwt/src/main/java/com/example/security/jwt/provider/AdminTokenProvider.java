package com.example.security.jwt.provider;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Date;

/**
 * This class is responsible for generating and validating JWT tokens for admin users.
 * It allows you to create a JWT token with claims such as subject, role, and permissions,
 * as well as validate and extract the claims from an incoming JWT token.
 *
 * The JWT token is signed using a secret key, which is injected from the application properties.
 * This class also provides the logic to validate whether the token has expired.
 *
 * Flow:
 * 1. The JWT token is generated with various claims (subject, role, permissions) and signed with a secret key.
 * 2. The generated token can be returned to the user (e.g., after a successful login).
 * 3. When the token is sent back to the server, it can be validated to ensure the user is authenticated and authorized.
 * 4. Claims from the token can be extracted and used to make authorization decisions.
 */
@Component
public class AdminTokenProvider {

    // Injected properties for secret key and various claims.
    @Value("${jwt.secret}")
    private String secretKeyString;

    @Value("${admin.jwt.claim.sub}")
    private String subject;  // The subject for the JWT comes from properties file.

    @Value("${admin.jwt.claim.role}")
    private String role;  // The role claim comes from properties file.

    @Value("${admin.jwt.claim.permission}")
    private String permissions;  // Permissions are specified in the properties file.

    @Value("${admin.jwt.claim.expiration.ms}")
    private long expirationTime;  // Token expiration time is specified in the properties file.

    private Key secretKey;

    /**
     * Initializes the secret key from the provided secret string in the application properties.
     * This secret key is used to sign the JWT token with the HS512 algorithm.
     *
     * The secret key is passed to the `SecretKeySpec` constructor to create a `Key` object
     * which will be used to sign the JWT token.
     */
    @Autowired
    public void init() {
        // Create a secret key from the injected secret string for HS512 signature algorithm
        this.secretKey = new SecretKeySpec(secretKeyString.getBytes(), SignatureAlgorithm.HS512.getJcaName());
    }

    /**
     * Generates a JWT token with the subject, role, permissions, and expiration time.
     *
     * This method uses the JJWT library to create a JWT token, adds claims (such as subject, role, and permissions),
     * sets the issued and expiration times, and signs the token with the secret key.
     *
     * @return The generated JWT token as a string.
     */
    public String generateToken() {
        return Jwts.builder()
                .setSubject(subject)  // Set the subject for the JWT token (admin identity).
                .claim("role", role)  // Add the user's role to the claims.
                .claim("permissions", permissions)  // Add the user's permissions to the claims.
                .setIssuedAt(new Date())  // Set the current date/time as the token issue date.
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))  // Set the token expiration time.
                .signWith(secretKey, SignatureAlgorithm.HS512)  // Sign the token with the secret key using HS512 algorithm.
                .compact();  // Return the JWT token as a string.
    }

    /**
     * Extracts and parses the claims from the provided JWT token.
     *
     * The JWT token is parsed using the secret key, and the claims are returned in the form of a `Claims` object.
     * The claims can include subject, role, permissions, and expiration date, which are used for authorization checks.
     *
     * @param token The JWT token from which the claims will be extracted.
     * @return The claims extracted from the JWT token.
     */
    public Claims getClaims(String token) {
        // Parse the JWT token and extract the claims using the secret key.
        return Jwts.parserBuilder()
                .setSigningKey(secretKey)  // Set the secret key to validate the JWT signature.
                .build()
                .parseClaimsJws(token)  // Parse the JWT and extract claims.
                .getBody();  // Return the claims body (excluding the header and signature).
    }

    /**
     * Validates the provided JWT token.
     *
     * This method validates the token by checking if the signature is correct and if the token has expired.
     * If the token is valid, it returns `true`; otherwise, it returns `false`.
     *
     * @param token The JWT token to validate.
     * @return `true` if the token is valid, `false` if the token is invalid or expired.
     */
    public boolean validateToken(String token) {
        try {
            // Extract claims from the token to check validity.
            Claims claims = getClaims(token);

            // Check if the token has expired by comparing the expiration date with the current time.
            Date expirationDate = claims.getExpiration();
            if (expirationDate.before(new Date())) {
                throw new JwtException("Token has expired");  // Token has expired, throw an exception.
            }

            // Token is valid if not expired and signature is correct.
            return true;
        } catch (JwtException e) {
            // Return false if the token is invalid (e.g., incorrect signature, expired).
            return false;
        }
    }
}
