package app;

import swarm.SecretManager;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        String secret = SecretManager.getSecret("SECRET_VALUE");

        System.out.println("[Main] secret: " + secret);

        while (true){
            Thread.sleep(50000);
        }

    }
}
