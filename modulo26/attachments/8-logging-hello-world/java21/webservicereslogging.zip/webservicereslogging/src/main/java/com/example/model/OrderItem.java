package com.example.model;

import com.example.model.key.OrderItemKey;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Order_Item", schema = "shop_schema")
@EqualsAndHashCode
@AllArgsConstructor
public class OrderItem {

    /**
     * Composite key for OrderItem.
     */
    @EmbeddedId // Marks this field as a composite primary key
    private OrderItemKey id;

    @ManyToOne // Defines a many-to-one relationship with Order
    @MapsId("order_id_pk") // Maps this field to the "order_id_pk" part of the composite key
    @JoinColumn(name = "order_id_fk") // Specifies the foreign key column
    private Order order;

    @ManyToOne // Defines a many-to-one relationship with Item
    @MapsId("item_id_pk") // Maps this field to the "item_id_pk" part of the composite key
    @JoinColumn(name = "item_id_fk", nullable = false) // Specifies the foreign key column
    private Item item;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;
}
