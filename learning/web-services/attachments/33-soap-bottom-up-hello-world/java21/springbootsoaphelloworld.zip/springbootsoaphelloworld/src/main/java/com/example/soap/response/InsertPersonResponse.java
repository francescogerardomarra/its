// This is the package declaration, indicating where this class resides in the project
package com.example.soap.response;

// Importing required annotations from Jakarta XML Binding (JAXB) to handle XML serialization and deserialization
import jakarta.xml.bind.annotation.XmlAccessType; // Defines the access level for the properties
import jakarta.xml.bind.annotation.XmlAccessorType; // Specifies how JAXB will access the fields
import jakarta.xml.bind.annotation.XmlElement; // Used to mark fields to be included in XML
import jakarta.xml.bind.annotation.XmlRootElement; // Marks the class as the root element in the XML
import lombok.Getter; // Lombok annotation to generate getter methods automatically
import lombok.Setter; // Lombok annotation to generate setter methods automatically

/**
 * This class is used for serializing the SOAP XML response message.
 *
 * Once the SOAP request is processed by the web service, the server needs to send back a response.
 * This response is formatted as an XML message, and this class is responsible for converting (serializing)
 * the Java object into the corresponding XML structure for the SOAP response.
 *
 * This class represents the "InsertPersonResponse" in the SOAP response message, which includes a message (e.g.,
 * "Person added successfully!").
 */
@XmlRootElement(name = "InsertPersonResponse", namespace = "http://example.com/soap") // This annotation marks the class as the root element in the XML document; it also ensures the correct namespace for the SOAP response message.
@XmlAccessorType(XmlAccessType.FIELD) // This tells JAXB to use the fields for XML binding (instead of getter/setter methods)
@Getter // Lombok annotation to automatically generate getter methods for all fields
@Setter // Lombok annotation to automatically generate setter methods for all fields
public class InsertPersonResponse {

    // Field to store the message, annotated with @XmlElement to specify it's a part of the XML structure
    @XmlElement(required = true) // The "message" field is mandatory in the XML document
    private String message; // A string message to be sent as a part of the response (e.g., "Person added successfully!")
}