package com.example.service;

import com.example.dto.item.ItemDTO;
import com.example.model.Item;
import com.example.repository.ItemRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ItemService {

    private static final Logger logger = LoggerFactory.getLogger(ItemService.class);
    private final ItemRepository itemRepository;

    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    // Create or update an Item
    public ItemDTO saveItem(ItemDTO itemDTO) {
        logger.info("Saving or updating item: {}", itemDTO); // Log the incoming item details

        Item item = new Item();
        item.setItemId(itemDTO.getItemId());
        item.setName(itemDTO.getName());
        item.setDescription(itemDTO.getDescription());
        item.setPrice(BigDecimal.valueOf(itemDTO.getPrice()));
        item.setStockQuantity(itemDTO.getStockQuantity() == null ? 0 : itemDTO.getStockQuantity());

        Item savedItem = itemRepository.save(item);

        // Log the saved item details
        logger.info("Item saved/updated: {}", savedItem);

        return new ItemDTO(
                savedItem.getItemId(),
                savedItem.getName(),
                savedItem.getDescription(),
                savedItem.getPrice().doubleValue(),
                savedItem.getStockQuantity()
        );
    }

    // Retrieve all Items
    public List<ItemDTO> getAllItems() {
        logger.info("Retrieving all items.");

        List<ItemDTO> items = itemRepository.findAll().stream()
                .map(item -> new ItemDTO(
                        item.getItemId(),
                        item.getName(),
                        item.getDescription(),
                        item.getPrice().doubleValue(),
                        item.getStockQuantity()
                ))
                .collect(Collectors.toList());

        // Log the list of items retrieved
        logger.info("Retrieved {} items.", items.size());

        return items;
    }

    // Retrieve an Item by ID
    public Optional<ItemDTO> getItemById(Integer itemId) {
        logger.info("Retrieving item by ID: {}", itemId);

        Optional<ItemDTO> itemDTO = itemRepository.findById(itemId).map(item -> new ItemDTO(
                item.getItemId(),
                item.getName(),
                item.getDescription(),
                item.getPrice().doubleValue(),
                item.getStockQuantity()
        ));

        if (itemDTO.isPresent()) {
            logger.info("Item found: {}", itemDTO.get());
        } else {
            logger.warn("Item with ID {} not found.", itemId);
        }

        return itemDTO;
    }

    // Delete an Item by ID
    public void deleteItem(Integer itemId) {
        logger.info("Deleting item with ID: {}", itemId);

        itemRepository.deleteById(itemId);

        // Log the deletion
        logger.info("Item with ID {} deleted successfully.", itemId);
    }
}
