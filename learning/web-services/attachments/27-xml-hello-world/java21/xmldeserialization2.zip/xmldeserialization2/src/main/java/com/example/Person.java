package com.example;

import jakarta.xml.bind.annotation.*;  // Import JAXB annotations for XML binding

// Annotates the class as a root element when converted to XML
@XmlRootElement(name = "person")
@XmlAccessorType(XmlAccessType.FIELD)  // Specifies that JAXB should bind the fields directly, not the getter/setter methods
public class Person {

    // Private fields to hold the person's data
    private String name;  // Name of the person
    private int age;  // Age of the person
    private String email;  // Email of the person (new field added)

    // Default constructor required by JAXB for deserialization (must be public or protected)
    public Person() {}

    // Getter method for the 'name' field
    public String getName() {
        return name;  // Returns the name of the person
    }

    // Setter method for the 'name' field
    public void setName(String name) {
        this.name = name;  // Sets the name of the person
    }

    // Getter method for the 'age' field
    public int getAge() {
        return age;  // Returns the age of the person
    }

    // Setter method for the 'age' field
    public void setAge(int age) {
        this.age = age;  // Sets the age of the person
    }

    // Getter method for the 'email' field
    public String getEmail() {
        return email;  // Returns the email of the person
    }

    // Setter method for the 'email' field
    public void setEmail(String email) {
        this.email = email;  // Sets the email of the person
    }
}