package com.example.controller;

import com.example.dto.orderitem.OrderItemDTO;
import com.example.rest.request.orderitem.AddItemToOrderRequest;
import com.example.rest.request.orderitem.RemoveItemFromOrderRequest;
import com.example.rest.response.orderitem.AddItemToOrderResponse;
import com.example.rest.response.orderitem.RemoveItemFromOrderResponse;
import com.example.service.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/shop/orderitems")
public class OrderItemController {

    private final OrderItemService orderItemService;

    @Autowired
    public OrderItemController(OrderItemService orderItemService) {
        this.orderItemService = orderItemService;
    }

    @PostMapping
    public ResponseEntity<AddItemToOrderResponse> addItemToOrder(@RequestBody AddItemToOrderRequest request) {
        // Convert the request into a DTO
        OrderItemDTO orderItemDTO = new OrderItemDTO(
                request.getOrderId(),
                request.getItemId(),
                request.getQuantity()
        );

        // Call the service layer
        Optional<OrderItemDTO> responseDTO = orderItemService.addItemToOrder(orderItemDTO);

        // Check if the order item was successfully added or not
        if (responseDTO.isEmpty()) {
            return ResponseEntity.badRequest().body(new AddItemToOrderResponse(
                    request.getOrderId(), request.getItemId(), request.getQuantity(), "Item not added to order."));
        }

        // Build a success response
        AddItemToOrderResponse response = new AddItemToOrderResponse(
                responseDTO.get().getOrderId(),
                responseDTO.get().getItemId(),
                responseDTO.get().getQuantity(),
                "Item successfully added to the order."
        );

        return ResponseEntity.ok(response);
    }

    @DeleteMapping
    public ResponseEntity<RemoveItemFromOrderResponse> removeItemFromOrder(@RequestBody RemoveItemFromOrderRequest request) {
        // Convert the request into a DTO
        OrderItemDTO orderItemDTO = new OrderItemDTO(
                request.getOrderId(),
                request.getItemId(),
                null  // Quantity is not needed for removal
        );

        // Call the service layer
        Optional<OrderItemDTO> responseDTO = orderItemService.removeItemFromOrder(orderItemDTO);

        // Check if the order item was successfully removed or not
        if (responseDTO.isEmpty()) {
            return ResponseEntity.badRequest().body(new RemoveItemFromOrderResponse(
                    request.getOrderId(), request.getItemId(), "Item not found in the order."));
        }

        // Build a success response
        RemoveItemFromOrderResponse response = new RemoveItemFromOrderResponse(
                responseDTO.get().getOrderId(),
                responseDTO.get().getItemId(),
                "Item successfully removed from the order."
        );

        return ResponseEntity.ok(response);
    }
}
