package com.example;

public class Main {
    public static void main(String[] args) {
        try {
            // Create a new Person object with name "John Doe" and age 30
            Person person = new Person("John Doe", 30);

            // Define the file path where the XML will be saved
            String filePath = "src/main/resources/person.xml";

            // Call the XMLHandler's serializeToXML method to serialize the Person object to the specified file
            XMLHandler.serializeToXML(person, filePath);

            // Print a success message indicating that the Person object was successfully serialized to XML
            System.out.println("SUCCESS - Serialized Person object to XML: " + filePath);
        } catch (Exception e) {
            // If an error occurs during the serialization process, print the error message
            System.err.println("FAILURE - Error during serialization: " + e.getMessage());
        }
    }
}