package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServiceRestSecurity {
    public static void main(String[] args) {
        SpringApplication.run(WebServiceRestSecurity.class, args);
    }
}
