package com.example.service;

import com.example.model.Item;
import com.example.model.Order;
import com.example.repository.ItemRepository;
import com.example.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ItemRepository itemRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository, ItemRepository itemRepository) {
        this.orderRepository = orderRepository;
        this.itemRepository = itemRepository;
    }

    // Create or update an Order
    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    // Retrieve all Orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // Retrieve an Order by ID
    public Optional<Order> getOrderById(Integer orderId) {
        return orderRepository.findById(orderId);
    }

    // Retrieve Orders by User ID
    public List<Order> getOrdersByUserId(Integer userId) {
        return orderRepository.findByUser_UserId(userId);
    }

    // Delete an Order by ID
    public void deleteOrder(Integer orderId) {
        orderRepository.deleteById(orderId);
    }

    // Add an item to an order
    public Optional<Order> addItemToOrder(Integer orderId, Integer itemId) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        Optional<Item> itemOpt = itemRepository.findById(itemId);

        if (orderOpt.isPresent() && itemOpt.isPresent()) {
            Order order = orderOpt.get();
            order.getItems().add(itemOpt.get());
            return Optional.of(orderRepository.save(order));
        }
        return Optional.empty();
    }

    // Remove an item from an order
    public Optional<Order> removeItemFromOrder(Integer orderId, Integer itemId) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        Optional<Item> itemOpt = itemRepository.findById(itemId);

        if (orderOpt.isPresent() && itemOpt.isPresent()) {
            Order order = orderOpt.get();
            order.getItems().remove(itemOpt.get());
            return Optional.of(orderRepository.save(order));
        }
        return Optional.empty();
    }

    // Get items in an order
    public Set<Item> getItemsInOrder(Integer orderId) {
        return orderRepository.findById(orderId)
                .map(Order::getItems)
                .orElse(Set.of());
    }
}
