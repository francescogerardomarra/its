package com.example.model.key;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable // Marks this class as an embeddable composite key
public class OrderItemKey implements java.io.Serializable {
    private Integer order_id_pk;
    private Integer item_id_pk;
}
