package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            // Deserialize JSON from file
            Person person = objectMapper.readValue(new File("src/main/resources/person.json"), Person.class);
            System.out.println("Deserialized Person: " + person.getName());

            // Serialize different Person objects to demonstrate annotations

            // 1. Basic serialization with @JsonProperty
            Person person1 = new Person("John Doe", 30);
            objectMapper.writeValue(new File("person1.json"), person1);
            // This will rename 'name' to 'full_name' in JSON output

            // 2. Ignoring a field with @JsonIgnore
            Person person2 = new Person("Jane Doe", 25);
            person2.setPassword("secret123");
            objectMapper.writeValue(new File("person2.json"), person2);
            // The 'password' field should not appear in the JSON file

            // 3. Using @JsonInclude to omit null fields
            Person person3 = new Person("Mike Ross", 40);
            objectMapper.writeValue(new File("person3.json"), person3);
            // 'email' will not be present in the JSON output because is null

            System.out.println("\nSerialized JSON files created successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

