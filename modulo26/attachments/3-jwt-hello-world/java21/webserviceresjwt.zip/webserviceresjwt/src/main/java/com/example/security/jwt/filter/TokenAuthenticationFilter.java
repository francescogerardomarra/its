package com.example.security.jwt.filter;

import com.example.security.jwt.admin.AdminTokenProvider;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Filter responsible for extracting the JWT token from incoming requests, validating it,
 * and setting the authentication context for authenticated users.
 *
 * This filter ensures that for every request (except those that are excluded from security),
 * the token is checked, and if valid, the user's authentication details are set in the SecurityContext.
 *
 * Flow:
 * 1. Extract the JWT token from the "Authorization" header of the incoming request.
 * 2. Validate the token using the AdminTokenProvider.
 * 3. If valid, extract the claims from the token and create an Authentication object.
 * 4. Set the Authentication object in the SecurityContext to authenticate the user.
 * 5. Proceed with the request by calling filterChain.doFilter().
 */
@Component
public class TokenAuthenticationFilter extends OncePerRequestFilter {

    // AdminTokenProvider is used to validate the JWT token and extract claims from it.
    private final AdminTokenProvider adminTokenProvider;

    /**
     * Constructor for injecting the AdminTokenProvider.
     *
     * @param adminTokenProvider The AdminTokenProvider used for validating and processing the JWT token.
     */
    @Autowired
    public TokenAuthenticationFilter(AdminTokenProvider adminTokenProvider) {
        this.adminTokenProvider = adminTokenProvider;
    }

    /**
     * This method is invoked for every HTTP request that passes through the filter chain.
     * It extracts the JWT token from the request, validates it, and sets the authentication in the SecurityContext
     * if the token is valid.
     *
     * @param request The HttpServletRequest, which contains the incoming request details.
     * @param response The HttpServletResponse, which is used to send the response to the client.
     * @param filterChain The FilterChain, which allows further filtering of the request.
     *
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException If an input/output error occurs.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        // Extract the token from the request's Authorization header
        String token = getTokenFromRequest(request);

        // If the token is not null and valid, authenticate the user
        if (token != null && adminTokenProvider.validateToken(token)) {
            // Get claims from the JWT token
            var claims = adminTokenProvider.getClaims(token);

            // Extract the username from the claims
            String username = claims.getSubject();

            // Create an authentication token with the username (null credentials as we use JWT for authentication)
            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(username, null, null);

            // Set the authentication in the SecurityContext, marking the user as authenticated
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }

        // Continue with the filter chain
        filterChain.doFilter(request, response);
    }

    /**
     * Extracts the JWT token from the Authorization header of the HTTP request.
     *
     * The token should be sent with the "Bearer " prefix in the Authorization header.
     * This method checks for that prefix and returns the actual token.
     *
     * @param request The HttpServletRequest object from which the token is extracted.
     * @return The JWT token as a string, or null if the token is not present or improperly formatted.
     */
    private String getTokenFromRequest(HttpServletRequest request) {
        // Get the Authorization header
        String bearerToken = request.getHeader("Authorization");

        // Check if the header contains a valid Bearer token
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            // Extract the token by removing the "Bearer " prefix
            return bearerToken.substring(7);  // Return the token without the "Bearer " prefix
        }

        // Return null if the token is missing or improperly formatted
        return null;
    }
}
