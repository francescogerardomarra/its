package swarm;

import java.io.IOException;
import java.nio.file.*;

public class SecretManager {
    public static String getSecret(String secretName) {
        String secretPath = "/run/secrets/" + secretName;
        String secret = "";

        try {
            secret = Files.readString(Paths.get(secretPath)).trim();
            System.out.println("[SecretManager] secret: " + secret);
        } catch (IOException e) {
            System.err.println("Failed to read secret: " + e.getMessage());
        }

        return secret;
    }
}
