package com.example.controller;

import com.example.model.Item;
import com.example.rest.request.item.ItemRequest;
import com.example.rest.response.item.ItemResponse;
import com.example.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Optional;

@RestController
@RequestMapping("/shop/items")  // Base path for all item-related endpoints
public class ItemController {

    private final ItemService itemService;

    @Autowired
    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    // Create a new item
    @PostMapping  // Method-level mapping
    public ResponseEntity<ItemResponse> createItem(@RequestBody ItemRequest itemRequest) {
        Item item = new Item();
        item.setName(itemRequest.getName());
        item.setDescription(itemRequest.getDescription());
        item.setPrice(BigDecimal.valueOf(itemRequest.getPrice()));
        item.setStockQuantity(0);  // Default stock quantity can be 0 or defined as needed

        Item savedItem = itemService.saveItem(item);

        // Creating the response
        ItemResponse response = new ItemResponse(
                savedItem.getItemId(),
                savedItem.getName(),
                savedItem.getDescription(),
                savedItem.getPrice().doubleValue(),
                savedItem.getStockQuantity()
        );

        return ResponseEntity.ok(response);
    }

    // Retrieve an item by its ID
    @GetMapping("/{itemId}")  // Method-level mapping with path variable
    public ResponseEntity<ItemResponse> getItemById(@PathVariable Integer itemId) {
        Optional<Item> item = itemService.getItemById(itemId);
        if (item.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Creating the response
        ItemResponse response = new ItemResponse(
                item.get().getItemId(),
                item.get().getName(),
                item.get().getDescription(),
                item.get().getPrice().doubleValue(),
                item.get().getStockQuantity()
        );

        return ResponseEntity.ok(response);
    }

    // Modify an existing item (update name, description, and price)
    @PutMapping("/{itemId}")  // Method-level mapping with path variable
    public ResponseEntity<ItemResponse> updateItem(@PathVariable Integer itemId, @RequestBody ItemRequest itemRequest) {
        Optional<Item> existingItem = itemService.getItemById(itemId);
        if (existingItem.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Item item = existingItem.get();
        if (itemRequest.getName() != null) item.setName(itemRequest.getName());
        if (itemRequest.getDescription() != null) item.setDescription(itemRequest.getDescription());
        if (itemRequest.getPrice() != null) item.setPrice(BigDecimal.valueOf(itemRequest.getPrice()));

        Item updatedItem = itemService.saveItem(item);

        // Creating the response
        ItemResponse response = new ItemResponse(
                updatedItem.getItemId(),
                updatedItem.getName(),
                updatedItem.getDescription(),
                updatedItem.getPrice().doubleValue(),
                updatedItem.getStockQuantity()
        );

        return ResponseEntity.ok(response);
    }
}
