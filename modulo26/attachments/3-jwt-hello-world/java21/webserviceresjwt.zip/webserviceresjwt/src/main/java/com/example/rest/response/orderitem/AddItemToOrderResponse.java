package com.example.rest.response.orderitem;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Response class for adding an Item to an Order.
 * This response will be used to confirm that an item has been successfully added to an order.
 */
@Getter
@Setter
@AllArgsConstructor
public class AddItemToOrderResponse {

    @JsonProperty("order_id")
    private Integer orderId;

    @JsonProperty("item_id")
    private Integer itemId;

    @JsonProperty("quantity")
    private Integer quantity;

    @JsonProperty("message")
    private String message;
}
